# GaGGos Projects 16.2

Öppna index.html eller: npm start. Test: npm test.

Live: https://gaggo-projects.netlify.app
GitHub Pages: https://thashamans-hub.github.io/gaggo-projects/
Repo: https://github.com/thashamans-hub/gaggo-projects

Allt ingår: källkod, dokumentation, screenshot, lokala badges, tester och SQL.
Publicera: dra in ZIP:en på Netlify Drop eller pusha filerna till repot.
