# MEGA PLAN v2 — AI PC Control → QA Copilot Pro

**Analyserad / utförd:** 2026-11-26
**Mål:** Förvandla röst/text-styrningen till en riktig QA-co Pilot för *Squadron TD: Pro Edition*,
med självständig spelkörning, verifiering, rapportering, live-dashboard och proffsig leverans.

---

## 0. Självanalys av nuvarande läge

**Styrkor som finns:**
- Fungerande bakgrundsapp (tray, globala genvägar, push-to-talk, lokal Whisper).
- Ollama + Anthropic, validerade åtgärder, panik, koordinatklampning.
- Scenariokörare med visuell verifiering och JSON-rapporter.

**Gap som identifierades (och åtgärdas här):**
1. Prompten är generisk TFT, medan spelet är **Squadron TD** med helt andra kontroller
   (1–6 tornnivåer, klicka ruta, klicka igen = upgrade, högerklick = sälj, W/G/S/A,
   Enter = våg, F5 = targeting, Esc = paus). → skräddarsydd prompt + scenarier.
2. `type` kan inte skriva å/ä/ö → lägg till clipboard-baserad `paste`.
3. Ingen ångra/upprepa-historik → spara kommandon i JSONL, Up/Down i rutan, upprepa-senaste.
4. Inget dry-run → riskabelt vid QA → dry-run-läge med tydlig status.
5. LLM-fel gör hela testkörningen instabil → retry med backoff + fallback Ollama→Anthropic.
6. Rapporter är bara JSON → HTML-rapport med skärmbilder, badges och tider.
7. Inga loopar i scenarier → `repeat` i DSL + `repeat`-åtgärd för soak-test.
8. Fryst skärm/black screen upptäcks inte → bilddiff-detektering per steg.
9. Ingen återkoppling när händerna är upptagna → TTS via Windows System.Speech.
10. Ingen överblick under långa körningar → lokal live-dashboard på `127.0.0.1:8765`.
11. Inga enhetstester → pytest-svit för parser, scenarier, rapporter, diff.
12. README/requirements/zip inte uppdaterade för detta.

---

## 1. Robusthet (`core/`)
- `core/metrics.py` — räknare för kommandon, åtgärder, LLM-anrop, latens, fel.
- `core/state.py` — delad körningsstatus + kommandohistorik (JSONL), trådsäker.
- `core/llm.py` — `generate_with_retry()` med exponentiell backoff och provider-fallback.
- `core/executor.py` — dry-run, paus, `paste`, `assert`, `repeat`, `notify`, metriker.

## 2. Persepsion & verifiering
- `core/verify.py` — `screen_diff_ratio()` för att upptäcka fryst/black screen.
- `prompts/verify.md` — HUD-specifika kontroller för Squadron TD.
- `prompts/squadron-td.md` — spelspecifik prompt med alla kontroller och QA-regler.

## 3. QA-motor (`game/`)
- `scenarios.py` — `repeat`, `assert_only`, `capture`; scenarier för Squadron TD:
  `squadron-smoke`, `squadron-build`, `squadron-economy`, `squadron-combat`,
  `squadron-settings`, `squadron-edge`, `squadron-soak`.
- `tft_tester.py` — omdöpt funktion: kör steg med screenshots, tidtagning,
  frozen-detection, repeat och skapar både JSON- och HTML-rapport.

## 4. UX / coolness (`ui/`, `input/`)
- `ui/report.py` — mörk HTML-rapport med inbäddade skärmbilder, PASS/FAIL-badges,
  metriker och tidslinje.
- `ui/dashboard.py` — live-webbUI med status, historik, senaste rapporter och
  formulär för att skicka kommandon (pollar `/api/state`).
- `ui/overlay.py` — historik med Up/Down och tydlig dry-run-/paus-indikator.
- `input/tts.py` — röståterkoppling via Windows System.Speech (inga extra beroenden).

## 5. Integrering
- `main.py` — allt ovan kopplat; tray-menyn får Dry-run, Paus, Upprepa senaste,
  Dashboard, Öppna rapporter, Kör test, Kör alla.

## 6. Kvalitet & leverans
- `tests/` — pytest-enhetstester.
- Uppdaterade `README.md`, `requirements.txt`, `.env.example`, `MEGA_PLAN.md`.
- Zip uppdaterad på skrivbordet (både spelzippen och en separat release-zip).

## 7. Definition of Done
- [x] Analys och plan
- [x] Robusthet: retry/fallback, metrics, state, dry-run, paus
- [x] Nya åtgärder: paste, assert, repeat, notify
- [x] Squadron TD-prompt och 7 scenarier
- [x] HTML + JSON-rapport + skärmbilder + frozen-detection
- [x] TTS, dashboard, historik, utökad tray
- [x] Enhetstester gröna (10/10)
- [x] Docs/requirements/.env.example uppdaterade
- [x] Zip uppdaterad på skrivbordet
