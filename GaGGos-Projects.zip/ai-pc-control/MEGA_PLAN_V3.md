# MEGA PLAN v3 — från skärmblick till instrumenterad QA

**Analyserad / utförd:** 2026-11-26
**Mål:** Ta QA Copilot Pro från "ser skärmen" till "ser insidan av spelet" — mätbar,
reproducerbar och CI-vänlig testning av Squadron TD.

---

## 0. Självanalys — vad saknas fortfarande?

v2 gjorde agenten visuell och rapporterbar. Kvarvarande gap:

1. **Allt bygger på skärmbilden.** Spelet är en webbapp på `localhost:3000`, men vi läser
   aldrig DOM, console eller JS-state. Spelets egen kvalitetsgräns är *"no console errors"*
   — den kan vi inte mäta alls i dag. → CDP-brygga.
2. **Inga strukturerade assertions.** `expect` är fritext till visionmodellen. → `expect_state`
   med JS-uttryck via CDP, kombinerat med vision.
3. **Ingen huvudlös/CI-körning.** Man måste starta tray + Tk + röst för att köra ett test.
   → CLI: `--doctor`, `--run`, `--list-scenarios`, `--fuzz`, `--dry-run`.
4. **Ingen reproducerbar fuzz.** Soak-scenariot kör samma sak. → seedad slumpmässig
   säker-åtgärdsgenerator med anomaly-detektering.
5. **Inga rörliga bevis.** Statiska bilder i rapporten. → GIF-tidslinje per körning.
6. **Ingen historik/trend.** Varje rapport är en ö. → `reports/index.html` med pass-rate.
7. **AI:n får inte veta vad testet förväntar sig.** → `hint` skickas till planeraren.
8. **Black screen upptäcks inte i köraren** (finns funktion men används ej). → koppla in.
9. **Ingen diagnostik.** → `tools/doctor.py`.

---

## 1. Instrumentering (`core/browser_bridge.py`)
- CDP-klient via `websocket-client`: anslut till `http://127.0.0.1:9222/json`,
  `Runtime.enable`, `Log.enable`.
- `evaluate(expr)`, `dom_text()`, `reload()`, `metrics()`, `drain()`.
- Samlar `console.error`, `uncaught exception` och `Log.entryAdded` med tidsstämpel.
- Valfritt (`BROWSER_CDP_ENABLED`), startar aldrig något automatiskt.

## 2. Strukturerade assertions och grindar
- `TestStep.expect_state` (JS-uttryck) → `StepResult.state_check`.
- `TestReport.console_errors`, `dom_before/after`, `perf`.
- `FAIL_ON_CONSOLE_ERROR` gör rapporten FAIL vid console-fel.
- Black-screen-check via `verify.is_black()` per steg.

## 3. CLI / CI (`main.py`, `tools/doctor.py`)
- `--doctor` — kontroll av python, paket, Ollama, modell, mikrofon, TTS, port, CDP.
- `--list-scenarios`, `--run <namn> [--repeat N]`, `--fuzz N --seed S`, `--dry-run`.
- Headless körning utan tray/Tk/voice, exit-kod 0/1 för CI.

## 4. Fuzz (`game/fuzzer.py`)
- Seedad RNG, grammar av säkra åtgärder (1–6, Enter, F5, Esc, klick i mitten, wait).
- Verifierar per iteration: fryst, black screen, console-fel.
- Reproducerbar via `--seed`.

## 5. Bevis och trend (`core/recorder.py`, `ui/report.py`)
- `FrameRecorder` → GIF med 4 fps, 480 px, max 120 frames, inbäddad i HTML-rapporten.
- `reports/index.html` med alla körningar, pass-rate och liten SVG-sparkline.

## 6. Prompt
- `Planner.plan(..., hint=...)` får veta förväntat utfall och skriver bättre planer.

## 7. Kvalitet & leverans
- Nya enhetstester (totalt ≥ 15).
- `README.md`, `requirements.txt`, `.env.example`, `MEGA_PLAN_V3.md`.
- `tools/package.py` kör igen → tre zippar på skrivbordet uppdaterade.

## 8. Definition of Done
- [x] Analys och plan
- [x] CDP-brygga + console/DOM/perf
- [x] expect_state + console-grind + black-screen
- [x] CLI: doctor / run / list / fuzz / dry-run
- [x] Fuzz med seed
- [x] GIF + trend-index
- [x] Planerar-hint
- [x] 16/16 tester gröna
- [x] Docs/requirements/.env uppdaterade
- [x] Zippar uppdaterade
