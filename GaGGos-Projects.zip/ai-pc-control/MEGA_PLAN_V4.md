# MEGA PLAN v4 — auktoritativ state, baselines och matriser

**Analyserad / utförd:** 2026-11-27
**Mål:** Gå från "läser skärmen" till "läser spelets sanna tillstånd" och göra testflödet
deterministiskt, reproducerbart och authorerbart.

---

## 0. Självanalys — nyckelfynd från källkoden

Jag läste `squadron-td/src/*.js` i zippen. Två avgörande fakta:

1. `src/main.js` exponerar **`window.Squadron = { UI }`**.
2. `src/ui.js` sätter **`this.game = new Game({...})`**.

Alltså finns hela den auktoritativa simuleringen på `window.Squadron.UI.game` —
mineraler, gas, workers, supply, fas, våg, torn, SS HP, stats, mutators. Vi behöver
inte gissa från pixlar. Detta är det största outnyttjade värdet i projektet.

**Övriga gap:**
- Inga **invariants** (mineraler ≥ 0, supply ≤ max, fas giltig, våg 1–31 …).
- Inga **golden baselines** → visuella regressioner upptäcks inte.
- Ingen **automatisk fokusering** av spelfönstret → tester failar om något annat fönster är överst.
- Ingen **matriskörning** över builders/difficulties/mutators.
- Ingen **sätt att skapa scenario med AI** (`--author`).
- Ingen **webhook** vid fail i CI.
- Trend-indexet visar inte **flakiness**.

---

## 1. Auktoritativ state (`core/game_probe.py`, `game/invariants.py`)
- `GameProbe.read()` → `Runtime.evaluate` av `window.Squadron.UI.game` → typad dict.
- `check_invariants(state)` → regellista med svenska felmeddelanden.
- Resultat sparas per steg i `StepResult.state` och `state_violations`.

## 2. Baselines (`core/baseline.py`)
- `save(scenario, step, image)` / `check(...)` med resize + `diff_ratio`.
- `BASELINE_ENABLED`, `BASELINE_THRESHOLD`, `--baseline-save`, `--baseline-check`.

## 3. Fokus (`core/window.py`)
- `pygetwindow` matchar `GAME_WINDOW_TITLE` och aktiverar fönstret före körning.
- Fallback: CDP `Page.bringToFront`.

## 4. Matris (`game/matrix.py`)
- Preset: `builders` (12), `difficulty` (4), `mutators`, `quick`.
- `{variabel}`-substitution i `command`, `expect`, `expect_state`.
- Budget (`MATRIX_BUDGET`) och sammanställd `matrix-<stamp>/summary.json`.

## 5. Authoring (`prompts/author.md`, CLI `--author`)
- Naturlig språkbeskrivning → AI:n skapar ett giltigt scenario-JSON.
- Valideras med `Scenario.load`, sparas till `--out`.

## 6. Webhook (`core/webhook.py`)
- POSTar `{scenario, passed, summary, html}` till `WEBHOOK_URL`.
- `WEBHOOK_ON=fail|always|never`.

## 7. Flakiness
- `reports/index.html` räknar pass-rate per scenario över de senaste körningarna
  och markerar < 100 % som **FLAKY**.

## 8. Kvalitet & leverans
- ≥ 22 enhetstester.
- README, requirements, .env.example, MEGA_PLAN_V4.
- `tools/package.py` → tre zippar på skrivbordet.

## 9. Definition of Done
- [x] Analys och plan
- [x] GameProbe + invariants
- [x] Baselines + fokus
- [x] Matris + author + webhook + flakiness
- [x] 24/24 tester gröna
- [x] Docs/requirements/.env uppdaterade
- [x] Zippar uppdaterade
