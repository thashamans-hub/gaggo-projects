# AI PC Control — QA Copilot Pro

En bakgrundsapplikation (systemtray-ikon, inget konsolfönster, inga fönster som stjäl fokus)
som styr mus och tangentbord via **röst**, **text**, **webbdashboard** eller **QA-scenarier**.

AI:n är antingen en **lokal Ollama-visionmodell** eller **Anthropic Claude**. Den får en
skärmbild + kontext och returnerar en lista med validerade åtgärder som körs med `pyautogui`.

Med `GAME_MODE=true` är agenten skräddarsydd för **Squadron TD: Pro Edition** (spelet i
`SquadronTD_Pro_Edition.zip`): den kan spela spelet, trycka på dess kontroller, verifiera
resultatet via skärmbilden och leverera både JSON- och HTML-rapporter med bilder.

> All källkod är lokal och granskningsbar. Appen gömmer sig inte för säkerhetsprogram och
> kringgår ingen anti-cheat — den styr bara din egen dator med din tillåtelse.

---

## Nyheter i Pro-versionen

| Funktion | Beskrivning |
|---|---|
| **Retry + fallback** | 3 försök med exponentiell backoff, valfri fallback Ollama ↔ Anthropic |
| **Torrkörning (dry-run)** | Planen loggas men mus/tangentbord rörs inte |
| **Pausa** | Stoppa alla körningar direkt från trayn |
| **Upprepa senaste** | `Ctrl+Alt+R` kör föregående kommando igen |
| **Kommandohistorik** | Sparas i `command-history.jsonl`, bläddra med ↑/↓ i input-rutan |
| **Nya åtgärder** | `paste` (Unicode-safe), `assert` (vision-check mitt i planen), `repeat`, `notify` |
| **TTS** | Röståterkoppling via Windows System.Speech — inga extra beroenden |
| **Live-dashboard** | `http://127.0.0.1:8765` med status, metriker, historik och kommandoformulär |
| **HTML-rapporter** | Mörk rapport med inbäddade skärmbilder, PASS/FAIL-badges och tider |
| **Fryst-detektering** | Bilddiff mellan två skärmbilder upptäcker fryst/black screen |
| **Scenarioloopar** | `repeat` per steg för soak/fuzz-test |
| **Enhetstester** | 24 pytest-tester (`pytest -q tests`) |
| **Webbläsarinstrumentering** | CDP: console-fel, DOM-text, JS-assertions, perf-metriker |
| **Headless CLI** | `--doctor`, `--run`, `--fuzz`, `--list-scenarios`, exit-kod för CI |
| **Seedad fuzz** | Reproducerbar slumpgång med anomaly-detektering |
| **GIF-bevis** | Inspelad tidslinje inbäddad i varje HTML-rapport |
| **Trend-index** | `reports/index.html` med pass-rate och sparkline |
| **Black-screen-detektering** | Upptäcks per steg och markeras i rapporten |
| **Auktorativ state** | Läser `window.Squadron.UI.game` via CDP och kontrollerar invariants |
| **Golden baselines** | Jämför skärmbild mot sparad referens och hittar visuella regressioner |
| **Matriskörning** | 12 builders / 4 svårigheter / 7 mutatorer med budget |
| **AI-authoring** | `--author "beskrivning"` skapar giltiga scenarier |
| **Webhook + flakiness** | Notis vid fail och FLAKY-markering i trend-indexet |
| **Automatisk fokus** | Aktiverar spelfönstret före varje körning |

---

## Installation

Kräver Python 3.10–3.13. **Använd 3.13** — `faster-whisper` (lokal STT) kan inte byggas på 3.15.

```bat
cd ai-pc-control
py -3.13 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

En `.venv` med allt installerat finns redan i projektet. `.env` skapas automatiskt från
`.env.example` vid första start.

### AI-leverantör

**Ollama (lokalt, rekommenderas):**
```bat
ollama pull qwen2.5vl:7b
```
```env
AI_PROVIDER=ollama
OLLAMA_MODEL=qwen2.5vl:7b
```
`qwen2.5vl` är en *vision-modell* — nödvändig för att läsa guld, torn, HUD och arenan.
Alternativ: `llama3.2-vision`, `gemma3`. För ren textstyrning funkar `llama3.1`.

**Anthropic:**
```env
AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-sonnet-4-5
```

**Fallback och retry:**
```env
FALLBACK_PROVIDER=anthropic
LLM_RETRIES=3
LLM_RETRY_DELAY=0.6
LLM_TIMEOUT=120
```
Om primären misslyckas tre gånger provas fallback-leverantören. Alla försök loggas och
räknas i metrikerna.

---

## Starta

```bat
run.bat
```
eller dubbelklicka **`start-hidden.vbs`** för helt utan konsolfönster,
eller `py -3.13 main.py`.

Tray-ikonen visar menyn:

- **Skriv kommando** (standardklick på ikonen)
- **Röst (håll Ctrl+Alt+Space)**
- **Upprepa senaste**
- **Dry-run** — kryssruta
- **Pausa / återuppta** — kryssruta
- **Kör test: `<scenario>`** / **Kör alla tester** (i spelläge)
- **Verktyg → Live-dashboard / Öppna rapporter**
- **Panik** och **Avsluta**

### Genvägar

| Genväg | Funktion |
|---|---|
| `Ctrl+Alt+S` | Öppna input-rutan. Skriv → Enter kör, Esc stänger, ↑/↓ bläddrar historik |
| `Ctrl+Alt+Space` (håll) | Push-to-talk. Släpp för att köra det du sa |
| `Ctrl+Alt+R` | Upprepa senaste kommando |
| `Ctrl+Alt+Esc` | Panik: avbryt allt och släpp nedhållna tangenter |

Alla genvägar går att ändra i `.env`.

### Exempelkommandon

- `"markera allt och kopiera"`
- `"klicka på sökfältet och skriv hej"`
- `"välj tornnivå 1, placera tre torn och starta vågen med Enter"`
- `"tryck F5 och öppna statistikpanelen"`

---

## CLI och CI (huvudlös körning)

Appen kan köras utan tray, Tk-fönster, röst och genvägar — vilket gör den användbar i CI
eller från en scheduler:

```bat
py -3.13 main.py --doctor                 :: kontrollera hela miljön
py -3.13 main.py --list-scenarios         :: lista scenarier
py -3.13 main.py --run squadron-build     :: kör ett scenario en gång
py -3.13 main.py --run squadron-soak --repeat 3
py -3.13 main.py --fuzz 50 --seed 1337    :: seedad slumpgång
py -3.13 main.py --run smoke --dry-run    :: planera utan att röra musen
py -3.13 main.py --list-matrices          :: lista matriser
py -3.13 main.py --run squadron-smoke --matrix quick
py -3.13 main.py --author "testa byggfasen på Hard"
py -3.13 main.py --run squadron-smoke --baseline-save
py -3.13 main.py --run squadron-smoke --baseline-check
```

`--run` och `--fuzz` skriver JSON + HTML-rapport och avslutar med **exit-kod 0 vid PASS,
1 vid FAIL** (2 vid okänt scenario). `--dry-run` och `--no-dashboard` kan kombineras med
valfritt läge. `--doctor` kontrollerar Python, alla moduler, Ollama + modell, Anthropic-nyckel,
mikrofon, TTS, dashboardport, CDP och rapportmappen — och varnar när något saknas.

Exempel på CI-steg:

```bat
py -3.13 main.py --doctor
py -3.13 main.py --run squadron-smoke
if errorlevel 1 exit /b 1
```

---

## Webbläsarinstrumentering (CDP)

Eftersom Squadron TD körs i webbläsaren kan testaren läsa *insidan* av spelet, inte bara
skärmen. Starta Chrome/Edge med fjärrfelsökning:

```bat
chrome.exe --remote-debugging-port=9222
```

Aktivera sen:

```env
BROWSER_CDP_ENABLED=true
CDP_URL=http://127.0.0.1:9222
CDP_TARGET_HINT=localhost
FAIL_ON_CONSOLE_ERROR=true
```

Då får du i rapporten:

- **console errors / exceptions** — hela listan sparas och gör rapporten FAIL när
  `FAIL_ON_CONSOLE_ERROR=true` (spelets egen kvalitetsgräns "no console errors").
- **DOM-text före/efter** — strukturerad HUD-avläsning som komplement till vision.
- **Performance-metriker** från `Performance.getMetrics`.
- **`expect_state`** — JS-uttryck per steg som måste returnera sant:

```json
{
  "name": "HUD finns",
  "command": "Titta på HUD:en.",
  "expect": "HUD:en visar mineraler och gas.",
  "expect_state": "document.body.innerText.includes('Minerals')"
}
```

Om CDP är avstängt markeras `expect_state` som *skipped* i stället för FAIL, så samma
scenario fungerar även utan instrumentering.

---

## Auktorativ state och invariants (v4)

Spelet exponerar `window.Squadron = { UI }` och `UI.game` är den riktiga `Game`-instansen.
Med CDP aktiverat läser `core/game_probe.py` den tillståndet direkt — mineraler, gas,
workers, supply, fas, våg, torn, SS HP, stats och mutatorer — och `game/invariants.py`
kontrollerar regler som:

- mineraler/gas/supply/torn/kills ≥ 0
- `supplyUsed <= supplyMax`
- `0 <= SS HP <= SS max HP`
- våg inom 1–31, giltig fas, hastighet 1x/2x, gas-tick i [0, 1)

Resultatet sparas per steg som `state`, `state_violations` och samlat som
`invariant_violations` i rapporten. Stäng av med `INVARIANT_CHECK=false`.

Innan varje körning aktiveras spelfönstret automatiskt (`AUTO_FOCUS_WINDOW=true`,
`GAME_WINDOW_TITLE=Squadron`). Om det inte hittas används CDP `Page.bringToFront`.

## Golden baselines

Spara referensbilder för ett scenario och jämför senare körningar:

```bat
py -3.13 main.py --run squadron-smoke --baseline-save
py -3.13 main.py --run squadron-smoke --baseline-check
```

Bilderna hamnar i `baselines/` (eller `BASELINE_DIR`) som
`<scenario>__<steg>.jpg`. `BASELINE_THRESHOLD=0.08` är maximal tillåten bilddiff.
Överskriden diff markerar steget FAIL som visuell regression.

## Matriser och AI-authoring

```bat
py -3.13 main.py --list-matrices
py -3.13 main.py --run squadron-smoke --matrix quick
py -3.13 main.py --run squadron-build --matrix builders
py -3.13 main.py --author "testa att bygga tre torn och starta vågen på Hard"
```

- `--matrix` substituerar `{builder}`, `{difficulty}` och `{mutator}` i kommandon,
  förväntningar och JS-uttryck. `MATRIX_BUDGET=24` begränsar antalet kombinationer.
  Resultat: `reports/matrix-<namn>-<tid>/summary.json` + `summary.html`.
- `--author` ber AI:n skapa ett giltigt scenario och sparar det (default
  `scenarios/<namn>.json`, eller `--out PATH`).

## Webhook och flakiness

Sätt `WEBHOOK_URL` och `WEBHOOK_ON=fail|always|never` för att posta
`{scenario, passed, summary, html, console_errors, invariant_violations}` till t.ex.
Slack/Discord vid testresultat. `reports/index.html` markerar dessutom scenario som
**FLAKY** när de senaste körningarna inte är enhetligt gröna.

---

## TTS, torrkörning och paus

- **TTS:** `TTS_ENABLED=true` gör att appen säger "Klart. 3 åtgärder." etc. via
  Windows System.Speech. Sätt `TTS_VOICE=Microsoft Anna` för att välja röst.
  `TTS_ENABLED=false` stänger av.
- **Dry-run:** sätt `DRY_RUN=true` i `.env` eller växla i trayn. Alla åtgärder loggas
  som `DRY-RUN: ...` men inget händer på skärmen — perfekt för att granska AI:ns plan.
- **Paus:** trayn stoppar både manuella kommandon och testkörningar utan att avsluta appen.

---

## Live-dashboard

Med `DASHBOARD_ENABLED=true` (default) öppnas `http://127.0.0.1:8765` via tray-menyn
**Verktyg → Live-dashboard**. Den visar:

- nuvarande status (inkl. **DRY-RUN** / **PAUSAD**)
- metriker: kommandon, åtgärder, LLM-anrop, snittlatens, fel, tester, pass/fail
- kommandohistorik med källa (text/röst/dashboard/upprepa)
- senaste QA-rapporter med direktlänk till HTML-rapporten
- ett formulär för att skicka kommandon direkt från webbläsaren

Sidan pollar `/api/state` varannan sekund. API: `GET /api/state`, `POST /api/command`,
`GET /report/<namn>`. Porten ändras med `DASHBOARD_PORT`.

---

## Åtgärder som AI:n får använda

`move`, `click`, `type`, **`paste`**, `hotkey`, `press`, `scroll`, `drag`, `key_down`,
`key_up`, `wait`, `screenshot`, **`assert`**, **`repeat`**, **`notify`**, `shell`, `open_app`.

- **`paste`** — klister in text via urklipp. Används för å/ä/ö och andra tecken som
  `pyautogui.write` inte klarar. Urklippet återställs efteråt.
- **`assert`** — visuell kontroll mitt i en plan:
  `{"action":"assert","condition":"Mineralerna har minskat.","on_fail":"abort"}`.
  Vid fail stoppas resten av planen och du får TTS-besked.
- **`repeat`** — loopar en lista av åtgärder:
  `{"action":"repeat","times":10,"actions":[{"action":"press","key":"f5"}]}`.
- **`notify`** — talar ett meddelande till testaren.

`shell` och `open_app` är avstängda som standard (`ALLOW_SHELL=false`,
`ALLOW_APP_LAUNCH=false`). Okända åtgärder kastas bort av `core/commands.py`.

---

## QA-läge för Squadron TD

Sätt `GAME_MODE=true` (default). Prompten `prompts/squadron-td.md` lär AI:n spelets
kontroller: `1`–`6` tornnivåer, vänsterklick = placera/upgrade, högerklick = sälj,
`W/G/S/A` ekonomi, `Enter` våg, `F5` targeting, `M` ljud, `Esc` paus, `H` hjälp,
toppfältet för hastighet/statistik. Varje svar innehåller en **observation** med
konkreta fakta från skärmen.

### Inbyggda scenarier

| Namn | Vad den testar |
|---|---|
| `squadron-smoke` | Lobbyn syns, matchen startar, paus/återuppta |
| `squadron-build` | Placera → uppgradera → sälj torn, resurskontroll |
| `squadron-economy` | `W`, `G`, `S`, `A` och HUD-uppdateringar |
| `squadron-combat` | Bygg, starta våg, fighters syns, nästa byggfas |
| `squadron-settings` | `F5`, `M`, `H`, statistikmodal |
| `squadron-edge` | Ogiltig ruta, snabba tangenttryck, uppgradera utan resurser |
| `squadron-soak` | 10× repeat, våg, fryst-detektering |
| `smoke` / `soak` | Generiska fall (bakåtkompatibilitet) |

Välj med `TEST_SCENARIO=squadron-build`, eller kör **Kör alla tester** i trayn.

### Eget scenario (JSON)

```json
{
  "name": "mitt-flode",
  "description": "Eget test av byggfasen",
  "steps": [
    {
      "name": "Starta spelet",
      "command": "Välj en builder och klicka Start Game.",
      "expect": "Byggfasen visas med HUD och byggruta.",
      "repeat": 1,
      "assert_only": false,
      "capture": true
    },
    {
      "name": "Bygg fem torn",
      "command": "Välj tornnivå 1 och placera fem torn.",
      "expect": "Fem torn står i byggruten och mineralerna har minskat."
    },
    {
      "name": "Kontrollera skärmen",
      "expect": "Skärmen är inte fryst och arenan är synlig.",
      "assert_only": true
    }
  ]
}
```

Peka `SCENARIO_FILE=mitt-flode.json` på filen.

- `command` → skickas till AI-plannern (som ser skärmbilden).
- `expect` → verifieras **efter** åtgärden via `prompts/verify.md`.
- `repeat` → kör steget N gånger (1–50), varje varv får egen rad i rapporten.
- `assert_only` → hoppa över AI:n och verifiera bara nuvarande skärm.
- `capture` → spara skärmbild per steg.

### Rapporter

Varje körning skapar en mapp `reports/<scenario>-<timestamp>/` med:

- `report.json` — maskinläsbart: thought, observation, åtgärder, tid, verification
  (`condition`, `passed`, `detail`, `evidence`), fryst-flagga, sökväg till bild
- `report.html` — fristående mörk rapport med inbäddade JPEG-bilder, PASS/FAIL-badges,
  metrik-kort och tidslinje (öppnas direkt från dashboarden eller trayn)
- `run.gif` — inspelad tidslinje (4 fps, 480 px) inbäddad överst i HTML-rapporten.
  Stäng av med `GIF_RECORDING=false`.
- `reports/index.html` — samlad översikt över alla körningar med pass-rate och sparkline
  (genereras om efter varje scenario)

`FROZEN_DETECTION=true` jämför två små skärmbilder med 0,6 s mellanrum. Under
`FROZEN_THRESHOLD` (default `0.004`) markeras steget med "⚠ fryst skärm misstänkt".

Tips: ha spelet i förgrunden och ostäckt, justera `TEST_DELAY` för animationer, och
använd en vision-modell — annars kan varken AI:n eller verifieraren se något.

### Seedad fuzz

Fuzzeren gör slumpgånger med en grammar av säkra åtgärder (`1`–`6`, `Enter`, `F5`, `Esc`,
klick i mitten av skärmen, `wait`) och kontrollerar efter varje steg för fryst skärm,
blackscreen och console-fel. Samma `--seed` ger exakt samma sekvens:

```bat
py -3.13 main.py --fuzz 100 --seed 1337
```

Resultatet sparas som `reports/fuzz-<seed>-<timestamp>/`. Använd `--dry-run` för att
först granska sekvensen utan att röra musen.

---

## Säkerhet

- Åtgärder valideras mot en fast vitlista i `core/commands.py`; okända kastas bort.
- Koordinater klampas till skärmen.
- `pyautogui.FAILSAFE` är på: musen till övre vänstra hörnet avbryter direkt.
- Panikgenvägen avbryter köer och släpper nedhållna tangenter.
- `shell`/`open_app` kräver `ALLOW_SHELL=true` / `ALLOW_APP_LAUNCH=true`.
- `risk=high` kräver bekräftelse i manuellt läge (`REQUIRE_CONFIRMATION=true`);
  obevakade testkörningar går utan dialog.

---

## Struktur

```
ai-pc-control/
├── main.py                 # entrypoint, tray, genvägar, integrering
├── config.py               # alla .env-inställningar
├── MEGA_PLAN.md            # självanalys och roadmap
├── core/
│   ├── commands.py         # validerade åtgärder + parse_plan
│   ├── context.py          # skärmbild, upplösning, aktivt fönster
│   ├── executor.py         # körning, dry-run, assert, repeat, notify
│   ├── llm.py              # Ollama/Anthropic, retry, fallback, JSON
│   ├── brain.py            # planerare (med hint om förväntat utfall)
│   ├── verify.py           # visuell verifiering + bilddiff + blackscreen
│   ├── metrics.py          # räknare till dashboarden
│   ├── state.py            # körningsstatus + kommandohistorik
│   ├── browser_bridge.py   # CDP: console, DOM, JS-assertions, perf
│   ├── game_probe.py       # läser window.Squadron.UI.game
│   ├── baseline.py         # golden images + bilddiff
│   ├── window.py           # fokuserar spelfönstret
│   ├── webhook.py          # notis till extern tjänst
│   └── recorder.py         # GIF-inspelning av testrundor
├── input/
│   ├── hotkeys.py          # genvägar + push-to-talk
│   ├── voice.py            # ljudinspelning + STT
│   └── tts.py              # röståterkoppling (System.Speech)
├── game/
│   ├── scenarios.py        # inbyggda + egna scenarier (expect_state, repeat)
│   ├── tft_tester.py       # scenariokörare + JSON/HTML/GIF-rapporter
│   ├── fuzzer.py           # seedad slumpgång + anomaly-detektering
│   ├── invariants.py       # regler för auktorativ state
│   ├── matrix.py           # matriser över builders/difficulty/mutators
│   └── author.py           # AI-genererade scenarier
├── ui/
│   ├── overlay.py          # input-ruta med historik
│   ├── dashboard.py        # live-webbUI
│   └── report.py           # HTML-rapportgenerator
├── prompts/
│   ├── system.md           # generell prompt
│   ├── squadron-td.md      # spelspecifik QA-prompt
│   ├── verify.md           # verifieringsprompt
│   └── author.md           # scenario-authoring-prompt
├── tools/
│   ├── doctor.py           # miljödiagnostik
│   └── package.py          # uppdaterar zipparna på skrivbordet
├── tests/test_core.py      # 24 enhetstester
├── reports/                # genererade tester + index.html (skapas vid körning)
├── run.bat / start-hidden.vbs
└── requirements.txt
```

## Kör testerna

```bat
py -3.13 -m pytest -q tests
```

## Definition of Done

- [x] Självanalys och MEGA-plan
- [x] Retry/fallback, metrics, state, dry-run, paus
- [x] paste, assert, repeat, notify
- [x] Squadron TD-prompt och 7 scenarier
- [x] HTML + JSON-rapporter, skärmbilder, fryst-detektering
- [x] TTS, dashboard, historik, utökad tray
- [x] 10/10 enhetstester gröna
- [x] README, requirements, .env.example och MEGA_PLAN uppdaterade
- [x] Zip uppdaterad på skrivbordet

### v3 — instrumenterad QA
- [x] CDP-brygga: console-fel, DOM-text, JS-assertions, perf
- [x] `expect_state`, console-grind och black-screen-detektering
- [x] CLI: `--doctor`, `--run`, `--list-scenarios`, `--fuzz`, `--dry-run`
- [x] Seedad fuzz med reproducerbara sekvenser
- [x] GIF-bevis och `reports/index.html` med pass-rate
- [x] Planerar-hint om förväntat utfall
- [x] 16/16 enhetstester gröna
- [x] Zippar uppdaterade igen

### v4 — auktoritativ QA
- [x] `GameProbe` läser `window.Squadron.UI.game` + invariant-regler
- [x] Golden baselines med `--baseline-save` / `--baseline-check`
- [x] Automatisk fokusering av spelfönstret
- [x] Matriser (builders/difficulty/mutators/quick) med budget
- [x] `--author` genererar giltiga scenarier med AI:n
- [x] Webhook-notis och FLAKY-markering i trend-indexet
- [x] 24/24 enhetstester gröna
- [x] Docs/requirements/.env uppdaterade och zippar ompaketerade
