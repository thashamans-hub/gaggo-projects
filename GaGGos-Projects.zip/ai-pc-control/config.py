"""Configuration loaded from environment / .env."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"))


def _str(name: str, default: str) -> str:
    return os.getenv(name, default)


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Config:
    # AI provider
    provider: str = _str("AI_PROVIDER", "ollama")
    fallback_provider: str = _str("FALLBACK_PROVIDER", "")

    ollama_base_url: str = _str("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
    ollama_model: str = _str("OLLAMA_MODEL", "qwen2.5vl:7b")
    anthropic_api_key: str = _str("ANTHROPIC_API_KEY", "")
    anthropic_model: str = _str("ANTHROPIC_MODEL", "claude-sonnet-4-5")

    max_tokens: int = _int("GENERATION_MAX_TOKENS", 1024)
    temperature: float = _float("GENERATION_TEMPERATURE", 0.2)
    llm_retries: int = _int("LLM_RETRIES", 3)
    llm_retry_delay: float = _float("LLM_RETRY_DELAY", 0.6)
    llm_timeout: int = _int("LLM_TIMEOUT", 120)

    # Voice
    voice_enabled: bool = _bool("VOICE_ENABLED", True)
    stt_backend: str = _str("STT_BACKEND", "local")
    whisper_model: str = _str("WHISPER_MODEL", "small")
    language: str = _str("LANGUAGE", "sv")

    # Global hotkeys
    text_hotkey: str = _str("TEXT_HOTKEY", "<ctrl>+<alt>+s")
    voice_hotkey: str = _str("VOICE_HOTKEY", "<ctrl>+<alt>+<space>")
    panic_hotkey: str = _str("PANIC_HOTKEY", "<ctrl>+<alt>+<esc>")
    repeat_hotkey: str = _str("REPEAT_HOTKEY", "<ctrl>+<alt>+r")

    # Safety / behaviour
    include_screenshot: bool = _bool("INCLUDE_SCREENSHOT", True)
    action_delay: float = _float("ACTION_DELAY", 0.08)
    require_confirmation: bool = _bool("REQUIRE_CONFIRMATION", True)
    allow_shell: bool = _bool("ALLOW_SHELL", False)
    allow_app_launch: bool = _bool("ALLOW_APP_LAUNCH", False)
    dry_run: bool = _bool("DRY_RUN", False)

    # Audio feedback
    tts_enabled: bool = _bool("TTS_ENABLED", True)
    tts_voice: str = _str("TTS_VOICE", "")

    # Live dashboard
    dashboard_enabled: bool = _bool("DASHBOARD_ENABLED", True)
    dashboard_port: int = _int("DASHBOARD_PORT", 8765)

    # Game / QA
    game_mode: bool = _bool("GAME_MODE", True)
    game_name: str = _str("GAME_NAME", "squadron-td")
    test_scenario: str = _str("TEST_SCENARIO", "squadron-smoke")
    scenario_file: str = _str("SCENARIO_FILE", "")
    test_delay: float = _float("TEST_DELAY", 0.5)
    reports_dir: str = _str("TEST_REPORTS_DIR", "reports")
    capture_screenshots: bool = _bool("CAPTURE_STEP_SCREENSHOTS", True)
    frozen_detection: bool = _bool("FROZEN_DETECTION", True)
    frozen_threshold: float = _float("FROZEN_THRESHOLD", 0.004)
    fail_on_console_error: bool = _bool("FAIL_ON_CONSOLE_ERROR", True)

    # Browser instrumentation (Chrome/Edge with --remote-debugging-port)
    browser_cdp_enabled: bool = _bool("BROWSER_CDP_ENABLED", False)
    cdp_url: str = _str("CDP_URL", "http://127.0.0.1:9222")
    cdp_target_hint: str = _str("CDP_TARGET_HINT", "localhost")
    cdp_timeout: int = _int("CDP_TIMEOUT", 5)

    # Evidence / fuzzing
    gif_recording: bool = _bool("GIF_RECORDING", True)
    gif_fps: int = _int("GIF_FPS", 4)
    gif_width: int = _int("GIF_WIDTH", 480)
    fuzz_seed: int = _int("FUZZ_SEED", 1337)

    # Authoritative state via window.Squadron.UI.game
    invariant_check: bool = _bool("INVARIANT_CHECK", True)
    auto_focus_window: bool = _bool("AUTO_FOCUS_WINDOW", True)
    game_window_title: str = _str("GAME_WINDOW_TITLE", "Squadron")

    # Golden baselines
    baseline_enabled: bool = _bool("BASELINE_ENABLED", False)
    baseline_check: bool = _bool("BASELINE_CHECK", True)
    baseline_threshold: float = _float("BASELINE_THRESHOLD", 0.08)
    baseline_dir: str = _str("BASELINE_DIR", "baselines")

    # Matrix / CI
    matrix_budget: int = _int("MATRIX_BUDGET", 24)
    webhook_url: str = _str("WEBHOOK_URL", "")
    webhook_on: str = _str("WEBHOOK_ON", "fail")

    # Storage
    history_file: str = _str("HISTORY_FILE", "command-history.jsonl")
    log_file: str = _str("LOG_FILE", "ai-control.log")

    @property
    def is_anthropic(self) -> bool:
        return self.provider.strip().lower() in {"anthropic", "claude"}

    def provider_names(self) -> list[str]:
        """Primary provider first, optional fallback second."""
        names = ["anthropic" if self.is_anthropic else "ollama"]
        fallback = self.fallback_provider.strip().lower()
        if fallback and fallback not in {names[0], "none", "off"}:
            names.append("anthropic" if fallback in {"anthropic", "claude"} else "ollama")
        return names
