"""Golden-image baselines for visual regression detection."""
from __future__ import annotations

import logging
import re
from pathlib import Path

from PIL import Image

from config import Config
from core.verify import diff_ratio

log = logging.getLogger("ai-control.baseline")


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", text.lower()).strip("-")[:60] or "step"


class BaselineManager:
    def __init__(self, config: Config, root: Path) -> None:
        self.enabled = config.baseline_enabled
        self.check_enabled = config.baseline_check
        self.threshold = config.baseline_threshold
        self.root = root / config.baseline_dir
        if self.enabled:
            self.root.mkdir(parents=True, exist_ok=True)

    def path(self, scenario: str, step: str) -> Path:
        return self.root / f"{_slug(scenario)}__{_slug(step)}.jpg"

    def _small(self, image: Image.Image) -> Image.Image:
        image = image.convert("RGB")
        ratio = 320 / max(1, image.width)
        return image.resize((320, max(1, int(image.height * ratio))), Image.LANCZOS)

    def save(self, scenario: str, step: str, image: Image.Image) -> str:
        if not self.enabled:
            return ""
        path = self.path(scenario, step)
        self._small(image).save(path, quality=80)
        return str(path)

    def check(self, scenario: str, step: str, image: Image.Image) -> dict:
        if not self.enabled:
            return {"skipped": True}
        path = self.path(scenario, step)
        if not path.exists():
            return {"skipped": True, "reason": "ingen baseline"}
        try:
            current = self._small(image)
            ratio = diff_ratio(Image.open(path).convert("RGB"), current)
            passed = ratio <= self.threshold
            return {
                "passed": passed,
                "diff": round(ratio, 4),
                "threshold": self.threshold,
                "baseline": str(path),
            }
        except Exception as exc:
            return {"passed": False, "error": str(exc)}
