"""AI planners: natural-language command + screen context -> validated action plan."""
from __future__ import annotations

import logging
from pathlib import Path

from config import Config
from core.commands import CommandPlan, parse_plan
from core.context import ScreenContext
from core.llm import extract_json, generate, load_prompt

log = logging.getLogger("ai-control.brain")


class Planner:
    def __init__(self, config: Config, prompt_name: str = "system") -> None:
        self.config = config
        self.prompt_name = prompt_name

    def plan(self, command: str, context: ScreenContext, hint: str = "") -> CommandPlan:
        hint_text = f"\n\nExpected outcome to plan for (use 'assert' where useful):\n{hint}" if hint else ""
        user_text = f"{context.describe()}\n\nUser command:\n{command}{hint_text}"
        text = generate(self.config, load_prompt(self.prompt_name), user_text, context)
        return parse_plan(extract_json(text))


def build_planner(config: Config, game_mode: bool = False) -> Planner:
    if not game_mode:
        return Planner(config, "system")
    prompts = Path(__file__).resolve().parent.parent / "prompts"
    wanted = config.game_name.strip().lower() or "squadron-td"
    name = wanted if (prompts / f"{wanted}.md").exists() else "squadron-td"
    log.info("Använder QA-prompt: %s", name)
    return Planner(config, prompt_name=name)
