"""Optional Chrome DevTools Protocol bridge for real game instrumentation.

Start Chrome/Edge with --remote-debugging-port=9222 and set BROWSER_CDP_ENABLED=true.
The bridge only reads the page and optionally reloads it; it never controls the OS.
"""
from __future__ import annotations

import json
import logging
import threading
import time

import requests

from config import Config

log = logging.getLogger("ai-control.cdp")


class BrowserBridge:
    def __init__(self, config: Config) -> None:
        self.enabled = config.browser_cdp_enabled
        self.cdp_url = config.cdp_url.rstrip("/")
        self.target_hint = config.cdp_target_hint.lower()
        self.timeout = config.cdp_timeout
        self._ws = None
        self._id = 0
        self._events: list[dict] = []
        self._lock = threading.Lock()
        self.target: dict = {}
        self.connected = False
        self.last_error = ""

    # ── connection ────────────────────────────────────────────
    def connect(self) -> bool:
        if not self.enabled or self.connected:
            return self.connected
        try:
            targets = requests.get(f"{self.cdp_url}/json", timeout=self.timeout).json()
            pages = [t for t in targets if t.get("type") == "page"]
            hinted = [t for t in pages if self.target_hint in t.get("url", "").lower()]
            chosen = hinted[0] if hinted else (pages[0] if pages else None)
            if not chosen:
                raise RuntimeError("Ingen webbsida hittades i CDP")
            import websocket

            self._ws = websocket.create_connection(
                chosen["webSocketDebuggerUrl"], timeout=self.timeout
            )
            self.target = chosen
            self._call("Runtime.enable")
            self._call("Log.enable")
            self._call("Page.enable")
            self.connected = True
            log.info("CDP ansluten: %s", chosen.get("url", ""))
            return True
        except Exception as exc:
            self.last_error = str(exc)
            log.warning("CDP kunde inte anslutas: %s", exc)
            return False

    def close(self) -> None:
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        self.connected = False

    # ── protocol ──────────────────────────────────────────────
    def _call(self, method: str, params: dict | None = None) -> dict:
        if not self.connected or not self._ws:
            raise RuntimeError("CDP är inte ansluten")
        with self._lock:
            self._id += 1
            call_id = self._id
            self._ws.send(json.dumps({"id": call_id, "method": method, "params": params or {}}))
            while True:
                message = json.loads(self._ws.recv())
                if message.get("id") == call_id:
                    return message.get("result", {})
                self._record_event(message)

    def _record_event(self, message: dict) -> None:
        method = message.get("method", "")
        params = message.get("params", {})
        if method == "Runtime.consoleAPICalled":
            level = str(params.get("type", "log")).lower()
            if level in {"error", "warning", "assert"}:
                self._events.append(
                    {
                        "at": time.strftime("%H:%M:%S"),
                        "level": level,
                        "text": " ".join(str(a.get("value", a.get("description", ""))) for a in params.get("args", [])),
                    }
                )
        elif method == "Runtime.exceptionThrown":
            details = params.get("exceptionDetails", {})
            self._events.append(
                {
                    "at": time.strftime("%H:%M:%S"),
                    "level": "exception",
                    "text": str(details.get("text", "")),
                }
            )
        elif method == "Log.entryAdded":
            entry = params.get("entry", {})
            if str(entry.get("level", "")).lower() in {"error", "warning"}:
                self._events.append(
                    {
                        "at": time.strftime("%H:%M:%S"),
                        "level": str(entry.get("level", "")).lower(),
                        "text": str(entry.get("text", "")),
                    }
                )
        if len(self._events) > 200:
            self._events = self._events[-200:]

    def drain(self, wait: float = 0.15) -> list[dict]:
        """Read pending CDP events without blocking the test run."""
        if not self.connected or not self._ws:
            return []
        import websocket

        deadline = time.time() + wait
        try:
            while time.time() < deadline:
                self._ws.settimeout(max(0.01, deadline - time.time()))
                self._record_event(json.loads(self._ws.recv()))
        except Exception:
            pass
        finally:
            try:
                self._ws.settimeout(self.timeout)
            except Exception:
                pass
        return list(self._events)

    def clear(self) -> None:
        self.drain(0.05)
        with self._lock:
            self._events = []

    def errors(self) -> list[dict]:
        return [event for event in self._events if event.get("level") in {"error", "exception", "assert"}]

    # ── useful queries ────────────────────────────────────────
    def evaluate(self, expression: str) -> object:
        result = self._call(
            "Runtime.evaluate",
            {"expression": expression, "returnByValue": True, "awaitPromise": False},
        )
        if "exceptionDetails" in result:
            raise RuntimeError(str(result["exceptionDetails"].get("text", "JS-fel")))
        return result.get("result", {}).get("value")

    def dom_text(self, limit: int = 8000) -> str:
        return str(self.evaluate(f"document.body && document.body.innerText ? document.body.innerText.slice(0,{limit}) : ''") or "")

    def reload(self) -> None:
        self._call("Page.reload", {"ignoreCache": True})
        time.sleep(0.6)

    def metrics(self) -> dict:
        result = self._call("Performance.getMetrics")
        return {item["name"]: item["value"] for item in result.get("metrics", [])}
