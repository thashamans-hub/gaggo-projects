"""Validated action models. AI output is parsed into these before anything runs."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

MouseButton = Literal["left", "right", "middle"]


def _as_int(value: Any) -> int:
    return int(round(float(value)))


def _as_int_or_none(value: Any) -> int | None:
    return None if value is None else _as_int(value)


class ActionBase(BaseModel):
    action: str
    reason: str = ""  # optional explanation from the AI, shown in logs

    model_config = {"extra": "ignore"}


class MoveMouse(ActionBase):
    action: Literal["move"] = "move"
    x: int
    y: int
    duration: float = 0.0

    @field_validator("x", "y", mode="before")
    @classmethod
    def _coerce(cls, value: Any) -> int:
        return _as_int(value)


class Click(ActionBase):
    action: Literal["click"] = "click"
    x: int | None = None
    y: int | None = None
    button: MouseButton = "left"
    clicks: int = 1
    interval: float = 0.1

    @field_validator("x", "y", mode="before")
    @classmethod
    def _coerce(cls, value: Any) -> int | None:
        return _as_int_or_none(value)


class TypeText(ActionBase):
    action: Literal["type"] = "type"
    text: str
    interval: float = 0.0


class Paste(ActionBase):
    """Unicode-safe text input via the clipboard (handles å/ä/ö and emoji)."""

    action: Literal["paste"] = "paste"
    text: str


class Hotkey(ActionBase):
    action: Literal["hotkey"] = "hotkey"
    keys: list[str]

    @field_validator("keys", mode="before")
    @classmethod
    def _normalize(cls, value: Any) -> list[str]:
        if isinstance(value, str):
            value = value.split("+")
        return [str(k).strip().lower() for k in value if str(k).strip()]


class Press(ActionBase):
    action: Literal["press"] = "press"
    key: str

    @field_validator("key", mode="before")
    @classmethod
    def _normalize(cls, value: Any) -> str:
        return str(value).strip().lower()


class Scroll(ActionBase):
    action: Literal["scroll"] = "scroll"
    amount: int
    x: int | None = None
    y: int | None = None

    @field_validator("amount", mode="before")
    @classmethod
    def _coerce_amount(cls, value: Any) -> int:
        return _as_int(value)

    @field_validator("x", "y", mode="before")
    @classmethod
    def _coerce_pos(cls, value: Any) -> int | None:
        return _as_int_or_none(value)


class Drag(ActionBase):
    action: Literal["drag"] = "drag"
    x1: int
    y1: int
    x2: int
    y2: int
    duration: float = 0.5

    @field_validator("x1", "y1", "x2", "y2", mode="before")
    @classmethod
    def _coerce(cls, value: Any) -> int:
        return _as_int(value)


class KeyDown(ActionBase):
    action: Literal["key_down"] = "key_down"
    key: str


class KeyUp(ActionBase):
    action: Literal["key_up"] = "key_up"
    key: str


class Wait(ActionBase):
    action: Literal["wait"] = "wait"
    seconds: float = 0.5


class Screenshot(ActionBase):
    action: Literal["screenshot"] = "screenshot"
    save_path: str = ""


class AssertScreen(ActionBase):
    """Mid-plan vision assertion. on_fail='abort' stops the remaining actions."""

    action: Literal["assert"] = "assert"
    condition: str
    on_fail: Literal["abort", "continue"] = "abort"


class Repeat(ActionBase):
    """Run a nested list of raw actions N times (handy for soak/fuzz tests)."""

    action: Literal["repeat"] = "repeat"
    times: int = 2
    actions: list[dict] = Field(default_factory=list)

    @field_validator("times", mode="before")
    @classmethod
    def _clamp(cls, value: Any) -> int:
        return max(1, min(100, _as_int(value)))


class Notify(ActionBase):
    action: Literal["notify"] = "notify"
    message: str


class Shell(ActionBase):
    action: Literal["shell"] = "shell"
    command: str


class OpenApp(ActionBase):
    action: Literal["open_app"] = "open_app"
    path: str


ACTION_TYPES: dict[str, type[ActionBase]] = {
    "move": MoveMouse,
    "click": Click,
    "type": TypeText,
    "paste": Paste,
    "hotkey": Hotkey,
    "press": Press,
    "scroll": Scroll,
    "drag": Drag,
    "key_down": KeyDown,
    "key_up": KeyUp,
    "wait": Wait,
    "screenshot": Screenshot,
    "assert": AssertScreen,
    "repeat": Repeat,
    "notify": Notify,
    "shell": Shell,
    "open_app": OpenApp,
}

HIGH_RISK = {"shell", "open_app", "key_down", "key_up"}


class AssertionFailed(RuntimeError):
    """Raised by an 'assert' action with on_fail='abort'."""


class CommandPlan(BaseModel):
    thought: str = ""
    observation: str = ""  # what the QA agent noticed on screen
    risk: Literal["low", "medium", "high"] = "low"
    actions: list[ActionBase] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)

    @property
    def is_high_risk(self) -> bool:
        return self.risk == "high" or any(a.action in HIGH_RISK for a in self.actions)


def parse_plan(data: Any) -> CommandPlan:
    """Turn raw AI JSON into a validated plan. Bad actions are skipped with errors."""
    if not isinstance(data, dict):
        return CommandPlan(errors=["AI:n returnerade inte ett JSON-objekt."])

    errors: list[str] = []
    raw_actions = data.get("actions", [])
    if not isinstance(raw_actions, list):
        errors.append("'actions' var inte en lista.")
        raw_actions = []

    actions: list[ActionBase] = []
    for index, raw in enumerate(raw_actions):
        if not isinstance(raw, dict):
            errors.append(f"Åtgärd {index + 1}: förväntade ett objekt.")
            continue
        name = str(raw.get("action", "")).strip().lower()
        model = ACTION_TYPES.get(name)
        if model is None:
            errors.append(f"Åtgärd {index + 1}: okänd åtgärd '{name}'.")
            continue
        try:
            actions.append(model.model_validate(raw))
        except Exception as exc:
            errors.append(f"Åtgärd {index + 1} ({name}): {exc}")

    risk = str(data.get("risk", "low")).strip().lower()
    if risk not in {"low", "medium", "high"}:
        risk = "medium" if errors else "low"

    return CommandPlan(
        thought=str(data.get("thought", ""))[:400],
        observation=str(data.get("observation", ""))[:400],
        risk=risk,  # type: ignore[arg-type]
        actions=actions,
        errors=errors,
    )
