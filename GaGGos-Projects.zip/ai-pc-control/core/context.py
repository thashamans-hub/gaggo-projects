"""Collect the context sent to the AI: screen size, active window, optional screenshot."""
from __future__ import annotations

import base64
import io
from dataclasses import dataclass

import pyautogui
from PIL import Image


@dataclass
class ScreenContext:
    width: int
    height: int
    active_window: str
    screenshot_b64: str | None = None

    def describe(self) -> str:
        lines = [
            f"Screen resolution: {self.width}x{self.height} px.",
            f"Active window: {self.active_window or 'unknown'}",
        ]
        if self.screenshot_b64:
            lines.append("A screenshot of the current screen is attached. Use it to find coordinates.")
        else:
            lines.append("No screenshot available. Use keyboard shortcuts when possible.")
        return "\n".join(lines)


def _active_window_title() -> str:
    try:
        import ctypes

        user32 = ctypes.windll.user32
        handle = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(handle)
        if not length:
            return ""
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(handle, buffer, length + 1)
        return buffer.value
    except Exception:
        return ""


def collect(with_screenshot: bool) -> ScreenContext:
    width, height = pyautogui.size()
    image_b64 = None
    if with_screenshot:
        try:
            screenshot = pyautogui.screenshot()
            screenshot.thumbnail((1280, 720), Image.LANCZOS)
            buffer = io.BytesIO()
            screenshot.convert("RGB").save(buffer, format="JPEG", quality=70)
            image_b64 = base64.b64encode(buffer.getvalue()).decode("ascii")
        except Exception:
            image_b64 = None
    return ScreenContext(
        width=int(width),
        height=int(height),
        active_window=_active_window_title(),
        screenshot_b64=image_b64,
    )
