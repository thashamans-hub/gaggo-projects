"""Executes validated actions with pyautogui, with safety guards and dry-run."""
from __future__ import annotations

import logging
import subprocess
import threading
import time
from collections.abc import Callable

import pyautogui
import pyperclip

from config import Config
from core.commands import (
    AssertScreen,
    AssertionFailed,
    Click,
    CommandPlan,
    Drag,
    Hotkey,
    KeyDown,
    KeyUp,
    MoveMouse,
    Notify,
    OpenApp,
    Paste,
    Press,
    Repeat,
    Screenshot,
    Scroll,
    Shell,
    TypeText,
    Wait,
    parse_plan,
)
from core.metrics import metrics

log = logging.getLogger("ai-control.executor")

# Moving the physical mouse to the top-left corner always aborts pyautogui.
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.0


class Executor:
    def __init__(
        self,
        config: Config,
        confirm: Callable[[CommandPlan], bool] | None = None,
        assert_callback: Callable[[str], bool] | None = None,
        notify_callback: Callable[[str], None] | None = None,
    ) -> None:
        self.config = config
        self.confirm = confirm
        self.assert_callback = assert_callback
        self.notify_callback = notify_callback
        self.dry_run = config.dry_run
        self.paused = False
        self._abort = threading.Event()
        self._held_keys: set[str] = set()

    def abort(self) -> None:
        """Panic button: stop the queue and release anything held down."""
        self._abort.set()
        for key in list(self._held_keys):
            try:
                pyautogui.keyUp(key)
            except Exception:
                pass
        self._held_keys.clear()
        log.warning("Panik: alla åtgärder avbrutna.")

    def run(self, plan: CommandPlan) -> int:
        """Execute a plan. Returns the number of actions performed."""
        if self._abort.is_set():
            self._abort.clear()
        if self.paused:
            log.info("Pausad – ignorerar kommando.")
            return 0

        if not plan.actions:
            log.warning("Inga giltiga åtgärder att köra. %s", " ".join(plan.errors))
            return 0

        if plan.is_high_risk and self.config.require_confirmation and self.confirm:
            if not self.confirm(plan):
                log.warning("Åtgärd avböjd av användaren.")
                return 0

        done = 0
        screen_w, screen_h = pyautogui.size()
        for action in plan.actions:
            if self._abort.is_set():
                break
            try:
                done += self._execute_one(action, int(screen_w), int(screen_h))
            except AssertionFailed as exc:
                log.error("Verifiering misslyckades: %s", exc)
                metrics.record_error(f"Assert: {exc}")
                self._notify(f"Verifiering misslyckades: {exc}")
                break
            except Exception as exc:
                log.error("Kunde inte köra %s: %s", action.action, exc)
                metrics.record_error(f"{action.action}: {exc}")
            time.sleep(max(0.0, self.config.action_delay))

        metrics.record_actions(done)
        return done

    def _log_action(self, action) -> None:
        prefix = "DRY-RUN" if self.dry_run else "Kör"
        log.info("%s: %s | %s", prefix, action.action, getattr(action, "reason", ""))

    def _notify(self, message: str) -> None:
        if self.notify_callback:
            try:
                self.notify_callback(message)
            except Exception:
                pass

    def _execute_one(self, action, screen_w: int, screen_h: int) -> int:
        self._log_action(action)

        if isinstance(action, Repeat):
            subplan = parse_plan({"actions": action.actions})
            count = 0
            for _ in range(action.times):
                if self._abort.is_set():
                    break
                for sub in subplan.actions:
                    if self._abort.is_set():
                        break
                    count += self._execute_one(sub, screen_w, screen_h)
                    time.sleep(max(0.0, self.config.action_delay))
            return count

        if self.dry_run:
            return 1

        if isinstance(action, MoveMouse):
            pyautogui.moveTo(self._clamp_x(action.x, screen_w), self._clamp_y(action.y, screen_h), action.duration)

        elif isinstance(action, Click):
            if action.x is not None and action.y is not None:
                pyautogui.click(
                    self._clamp_x(action.x, screen_w),
                    self._clamp_y(action.y, screen_h),
                    clicks=max(1, action.clicks),
                    interval=max(0.0, action.interval),
                    button=action.button,
                )
            else:
                pyautogui.click(clicks=max(1, action.clicks), interval=max(0.0, action.interval), button=action.button)

        elif isinstance(action, TypeText):
            pyautogui.write(action.text, interval=max(0.0, action.interval))

        elif isinstance(action, Paste):
            previous = ""
            try:
                previous = pyperclip.paste()
            except Exception:
                pass
            pyperclip.copy(action.text)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.15)
            if previous:
                pyperclip.copy(previous)

        elif isinstance(action, Hotkey):
            pyautogui.hotkey(*action.keys)

        elif isinstance(action, Press):
            pyautogui.press(action.key)

        elif isinstance(action, Scroll):
            if action.x is not None and action.y is not None:
                pyautogui.moveTo(self._clamp_x(action.x, screen_w), self._clamp_y(action.y, screen_h))
            pyautogui.scroll(action.amount)

        elif isinstance(action, Drag):
            pyautogui.moveTo(self._clamp_x(action.x1, screen_w), self._clamp_y(action.y1, screen_h))
            pyautogui.dragTo(
                self._clamp_x(action.x2, screen_w),
                self._clamp_y(action.y2, screen_h),
                duration=max(0.05, action.duration),
                button="left",
            )

        elif isinstance(action, KeyDown):
            pyautogui.keyDown(action.key)
            self._held_keys.add(action.key)

        elif isinstance(action, KeyUp):
            pyautogui.keyUp(action.key)
            self._held_keys.discard(action.key)

        elif isinstance(action, Wait):
            time.sleep(min(30.0, max(0.0, action.seconds)))

        elif isinstance(action, Screenshot):
            image = pyautogui.screenshot()
            path = action.save_path or "screenshot.png"
            image.save(path)
            log.info("Skärmbild sparad: %s", path)

        elif isinstance(action, AssertScreen):
            passed = bool(self.assert_callback(action.condition)) if self.assert_callback else True
            log.info("Verifiering %s: %s", "PASS" if passed else "FAIL", action.condition)
            if not passed and action.on_fail == "abort":
                raise AssertionFailed(action.condition)

        elif isinstance(action, Notify):
            self._notify(action.message)

        elif isinstance(action, Shell):
            if not self.config.allow_shell:
                raise PermissionError("Skalskommandon är avstängda (ALLOW_SHELL=false).")
            subprocess.Popen(action.command, shell=True)

        elif isinstance(action, OpenApp):
            if not self.config.allow_app_launch:
                raise PermissionError("Appstart är avstängd (ALLOW_APP_LAUNCH=false).")
            subprocess.Popen(action.path, shell=True)

        return 1

    @staticmethod
    def _clamp_x(value: int, screen_w: int) -> int:
        return max(1, min(screen_w - 2, value))

    @staticmethod
    def _clamp_y(value: int, screen_h: int) -> int:
        return max(1, min(screen_h - 2, value))
