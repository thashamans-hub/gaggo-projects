"""Reads Squadron TD's authoritative simulation state through CDP.

The game exposes window.Squadron = { UI } and UI.game is the Game instance.
Everything here is read-only; no game state is mutated by the QA tool.
"""
from __future__ import annotations

import logging
from typing import Any

from config import Config
from core.browser_bridge import BrowserBridge

log = logging.getLogger("ai-control.probe")

STATE_EXPRESSION = r"""(() => {
  const ui = window.Squadron && window.Squadron.UI;
  const g = ui && ui.game;
  if (!g) return null;
  const b = g.board || {};
  const ss = g.ss || (g.self && g.self.ss) || null;
  const totals = (g.stats && g.stats.totals) || {};
  const muts = g.mutators || [];
  const num = v => typeof v === 'number' && Number.isFinite(v) ? v : null;
  return {
    source: 'window.Squadron.UI.game',
    phase: g.currentPhase || null,
    wave: num(g.wave),
    minerals: num(b.minerals),
    gas: num(b.gas),
    workers: num(b.workers),
    income: num(b.income),
    supplyUsed: num(b.supplyUsed),
    supplyMax: num(b.supplyMax),
    gasLevel: num(b.gasLevel),
    speedLevel: num(b.speedLevel),
    ssLevel: num(b.ssLevel),
    towers: Array.isArray(b.towers) ? b.towers.length : null,
    ssHp: ss ? num(ss.hp) : null,
    ssMaxHp: ss ? num(ss.maxHp) : null,
    paused: !!g.paused,
    speed: num(g.speed),
    builder: (g.builder && g.builder.name) || null,
    difficulty: (g.difficulty && g.difficulty.id) || null,
    mutators: muts.map(m => (typeof m === 'string' ? m : (m.id || m.name || ''))).filter(Boolean),
    kills: num(totals.kills),
    leaks: num(totals.leaks),
    time: num(g.time),
    gasTickAcc: num(g.gasTickAcc)
  };
})()"""


class GameProbe:
    def __init__(self, config: Config, bridge: BrowserBridge) -> None:
        self.enabled = config.invariant_check
        self.bridge = bridge
        self.last_error = ""

    def read(self) -> dict | None:
        if not self.enabled or not self.bridge.connected:
            return None
        try:
            value = self.bridge.evaluate(STATE_EXPRESSION)
            if not isinstance(value, dict):
                self.last_error = "window.Squadron.UI.game är inte tillgängligt i denna fas"
                return None
            return value
        except Exception as exc:
            self.last_error = str(exc)
            log.debug("Kunde inte läsa spelstate: %s", exc)
            return None
