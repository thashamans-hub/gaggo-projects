"""Shared LLM calls with retries and provider fallback, plus JSON extraction."""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

import requests

from config import Config
from core.context import ScreenContext
from core.metrics import metrics


class LLMError(RuntimeError):
    """Raised when every provider/attempt failed."""


def load_prompt(name: str) -> str:
    path = Path(__file__).resolve().parent.parent / "prompts" / f"{name}.md"
    return path.read_text(encoding="utf-8") if path.exists() else "Return only a JSON object."


def extract_json(text: str) -> object:
    """Strip markdown fences and grab the first balanced JSON object."""
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.IGNORECASE)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError(f"No JSON object found in: {text[:200]!r}")
    return json.loads(text[start : end + 1])


def _generate_anthropic(config: Config, system_prompt: str, user_text: str, context: ScreenContext) -> str:
    from anthropic import Anthropic

    if not config.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY saknas i .env")
    content: list[dict] = []
    if context.screenshot_b64:
        content.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": context.screenshot_b64,
                },
            }
        )
    content.append({"type": "text", "text": user_text})
    message = Anthropic(api_key=config.anthropic_api_key).messages.create(
        model=config.anthropic_model,
        max_tokens=config.max_tokens,
        temperature=config.temperature,
        system=system_prompt,
        messages=[{"role": "user", "content": content}],
    )
    return "".join(block.text for block in message.content if getattr(block, "type", None) == "text")


def _generate_ollama(config: Config, system_prompt: str, user_text: str, context: ScreenContext) -> str:
    messages: list[dict] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_text},
    ]
    if context.screenshot_b64:
        messages[-1]["images"] = [context.screenshot_b64]
    payload = {
        "model": config.ollama_model,
        "stream": False,
        "format": "json",
        "messages": messages,
        "options": {"temperature": config.temperature},
    }
    response = requests.post(
        f"{config.ollama_base_url.rstrip('/')}/api/chat",
        json=payload,
        timeout=config.llm_timeout,
    )
    response.raise_for_status()
    return response.json().get("message", {}).get("content", "")


def generate(config: Config, system_prompt: str, user_text: str, context: ScreenContext) -> str:
    """Try each configured provider with exponential backoff. Records metrics."""
    providers = config.provider_names()
    last_error: Exception | None = None

    for provider in providers:
        for attempt in range(max(1, config.llm_retries)):
            started = time.perf_counter()
            try:
                if provider == "anthropic":
                    text = _generate_anthropic(config, system_prompt, user_text, context)
                else:
                    text = _generate_ollama(config, system_prompt, user_text, context)
                if not text.strip():
                    raise RuntimeError(f"Tomt svar från {provider}")
                metrics.record_llm((time.perf_counter() - started) * 1000)
                return text
            except Exception as exc:
                last_error = exc
                metrics.record_llm((time.perf_counter() - started) * 1000, failed=True)
                metrics.record_error(f"{provider} försök {attempt + 1}: {exc}")
                if attempt < max(1, config.llm_retries) - 1:
                    time.sleep(max(0.0, config.llm_retry_delay) * (2**attempt))

    raise LLMError(f"Alla AI-leverantörer misslyckades: {last_error}")
