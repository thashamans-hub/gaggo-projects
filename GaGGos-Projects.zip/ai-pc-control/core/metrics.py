"""Lightweight process-wide counters used by the dashboard and reports."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field


@dataclass
class Metrics:
    started_at: float = field(default_factory=time.time)
    commands: int = 0
    actions: int = 0
    llm_calls: int = 0
    llm_failures: int = 0
    llm_latency_ms: list[float] = field(default_factory=list)
    tests_run: int = 0
    steps_passed: int = 0
    steps_failed: int = 0
    errors: list[str] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def record_command(self) -> None:
        with self._lock:
            self.commands += 1

    def record_actions(self, count: int) -> None:
        with self._lock:
            self.actions += count

    def record_llm(self, latency_ms: float, failed: bool = False) -> None:
        with self._lock:
            self.llm_calls += 1
            if failed:
                self.llm_failures += 1
            self.llm_latency_ms.append(round(latency_ms, 1))
            if len(self.llm_latency_ms) > 200:
                self.llm_latency_ms.pop(0)

    def record_test(self, passed: int, failed: int) -> None:
        with self._lock:
            self.tests_run += 1
            self.steps_passed += passed
            self.steps_failed += failed

    def record_error(self, message: str) -> None:
        with self._lock:
            self.errors.append(message[:300])
            if len(self.errors) > 50:
                self.errors.pop(0)

    def snapshot(self) -> dict:
        with self._lock:
            latencies = list(self.llm_latency_ms)
            data = {
                "commands": self.commands,
                "actions": self.actions,
                "llm_calls": self.llm_calls,
                "llm_failures": self.llm_failures,
                "tests_run": self.tests_run,
                "steps_passed": self.steps_passed,
                "steps_failed": self.steps_failed,
                "errors": list(self.errors),
            }
        data["avg_llm_latency_ms"] = round(sum(latencies) / len(latencies), 1) if latencies else 0.0
        data["uptime_seconds"] = int(time.time() - self.started_at)
        return data


metrics = Metrics()
