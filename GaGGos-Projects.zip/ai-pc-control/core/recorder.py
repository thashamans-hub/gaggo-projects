"""Records a lightweight GIF timeline of a QA run."""
from __future__ import annotations

import logging
import time
from pathlib import Path

import pyautogui
from PIL import Image

log = logging.getLogger("ai-control.recorder")


class FrameRecorder:
    def __init__(self, enabled: bool, fps: int = 4, width: int = 480, max_frames: int = 120) -> None:
        self.enabled = enabled
        self.fps = max(1, fps)
        self.width = max(160, width)
        self.max_frames = max(2, max_frames)
        self.frames: list[Image.Image] = []
        self.started = time.time()

    def add(self) -> None:
        if not self.enabled or len(self.frames) >= self.max_frames:
            return
        try:
            image = pyautogui.screenshot().convert("RGB")
            ratio = self.width / image.width
            image = image.resize((self.width, max(1, int(image.height * ratio))), Image.LANCZOS)
            self.frames.append(image)
        except Exception as exc:
            log.warning("Kunde inte spela in bild: %s", exc)

    def save(self, path: Path) -> str:
        if not self.enabled or not self.frames:
            return ""
        try:
            duration = int(1000 / self.fps)
            self.frames[0].save(
                path,
                save_all=True,
                append_images=self.frames[1:],
                duration=duration,
                loop=0,
                optimize=True,
            )
            return str(path)
        except Exception as exc:
            log.warning("Kunde inte spara GIF: %s", exc)
            return ""
