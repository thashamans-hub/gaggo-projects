"""Shared, thread-safe runtime state and persistent command history."""
from __future__ import annotations

import json
import threading
import time
from collections import deque
from pathlib import Path

from config import Config
from core.metrics import metrics


class StateStore:
    def __init__(self, config: Config) -> None:
        self.path = Path(__file__).resolve().parent.parent / config.history_file
        self.lock = threading.RLock()
        self.status = "Idle"
        self.busy = False
        self.paused = False
        self.dry_run = config.dry_run
        self.last_command = ""
        self.last_report = ""
        self.history: deque[dict] = deque(maxlen=200)
        self._load()

    def _load(self) -> None:
        try:
            if self.path.exists():
                for line in self.path.read_text(encoding="utf-8").splitlines()[-200:]:
                    if line.strip():
                        self.history.append(json.loads(line))
        except Exception:
            pass

    def set(self, status: str, busy: bool | None = None) -> None:
        with self.lock:
            self.status = status
            if busy is not None:
                self.busy = busy

    def add_command(self, text: str, source: str = "text") -> None:
        entry = {
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "source": source,
            "command": text,
        }
        with self.lock:
            self.last_command = text
            self.history.append(entry)
            try:
                with self.path.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
            except Exception:
                pass

    def recent_history(self, limit: int = 30) -> list[dict]:
        with self.lock:
            return list(self.history)[-limit:][::-1]

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "status": self.status,
                "busy": self.busy,
                "paused": self.paused,
                "dry_run": self.dry_run,
                "last_command": self.last_command,
                "last_report": self.last_report,
                "history": self.recent_history(30),
                "metrics": metrics.snapshot(),
            }
