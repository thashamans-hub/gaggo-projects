"""Vision-based assertion: does the screen currently satisfy a condition?"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass

import pyautogui
from PIL import Image, ImageChops, ImageStat

from config import Config
import core.context as screen_context
from core.context import ScreenContext
from core.llm import extract_json, generate, load_prompt

log = logging.getLogger("ai-control.verify")


@dataclass
class Verification:
    condition: str
    passed: bool
    detail: str
    evidence: str


class Verifier:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.prompt = load_prompt("verify")

    def check(self, condition: str, context: ScreenContext | None = None) -> Verification:
        context = context or screen_context.collect(self.config.include_screenshot)
        text = generate(
            self.config,
            self.prompt,
            f"Condition to verify:\n{condition}\n\n{context.describe()}",
            context,
        )
        try:
            data = extract_json(text)
        except Exception as exc:
            log.warning("Kunde inte tolka verifieringssvar: %s", exc)
            return Verification(condition, False, "Verifieringssvar kunde inte tolkas.", str(exc))
        return Verification(
            condition=condition,
            passed=bool(data.get("passed", False)),
            detail=str(data.get("detail", "")),
            evidence=str(data.get("evidence", "")),
        )

    def is_frozen(self, seconds: float = 0.6) -> tuple[bool, float]:
        """Two small screenshots: almost no change means a frozen/black screen."""
        first = _small_screenshot()
        time.sleep(max(0.05, seconds))
        second = _small_screenshot()
        ratio = diff_ratio(first, second)
        return ratio < self.config.frozen_threshold, ratio


def _small_screenshot() -> Image.Image:
    return pyautogui.screenshot().convert("RGB").resize((160, 90))


def diff_ratio(first: Image.Image, second: Image.Image) -> float:
    """Fraction of pixels that changed noticeably between two images."""
    diff = ImageChops.difference(first, second).convert("L")
    histogram = diff.histogram()
    total = first.width * first.height
    changed = sum(histogram[16:])
    return changed / max(1, total)


def is_black(image: Image.Image) -> bool:
    mean = ImageStat.Stat(image.convert("L")).mean[0]
    return mean < 12
