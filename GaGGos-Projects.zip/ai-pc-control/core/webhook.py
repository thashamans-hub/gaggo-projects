"""Optional webhook notification when a test run finishes."""
from __future__ import annotations

import json
import logging

import requests

from config import Config

log = logging.getLogger("ai-control.webhook")


def notify(config: Config, payload: dict) -> bool:
    mode = config.webhook_on.strip().lower()
    url = config.webhook_url.strip()
    if not url or mode == "never":
        return False
    if mode == "fail" and payload.get("passed"):
        return False
    try:
        requests.post(url, json=payload, timeout=8)
        return True
    except Exception as exc:
        log.warning("Webhook misslyckades: %s", exc)
        return False
