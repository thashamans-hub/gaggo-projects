"""Focus the game window before a test run so clicks land in the right place."""
from __future__ import annotations

import logging

from config import Config
from core.browser_bridge import BrowserBridge

log = logging.getLogger("ai-control.window")


def focus_game_window(config: Config, bridge: BrowserBridge | None = None) -> str:
    if config.auto_focus_window:
        try:
            import pygetwindow

            wanted = config.game_window_title.strip().lower()
            windows = [w for w in pygetwindow.getAllWindows() if wanted and wanted in w.title.lower()]
            if windows:
                window = windows[0]
                if window.isMinimized:
                    window.restore()
                window.activate()
                log.info("Fokuserade fönster: %s", window.title)
                return window.title
        except Exception as exc:
            log.debug("Kunde inte fokusera via pygetwindow: %s", exc)

    if bridge and bridge.enabled and bridge.connected:
        try:
            bridge._call("Page.bringToFront")
            log.info("Fokuserade CDP-fliken: %s", bridge.target.get("url", ""))
            return str(bridge.target.get("url", "cdp-tab"))
        except Exception as exc:
            log.debug("Kunde inte fokusera via CDP: %s", exc)

    return ""
