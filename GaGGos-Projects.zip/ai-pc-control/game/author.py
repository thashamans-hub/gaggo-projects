"""Generate a validated scenario JSON from a natural-language description."""
from __future__ import annotations

import re
from pathlib import Path

from config import Config
from core.context import ScreenContext
from core.llm import extract_json, generate, load_prompt
from game.scenarios import Scenario, TestStep


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", text.lower()).strip("-")[:50] or "generated"


def author_scenario(config: Config, description: str, out_path: str | Path | None = None) -> Path:
    empty_context = ScreenContext(width=0, height=0, active_window="", screenshot_b64=None)
    text = generate(
        config,
        load_prompt("author"),
        f"Beskrivning av testet:\n{description}",
        empty_context,
    )
    data = extract_json(text)
    if not isinstance(data, dict):
        raise ValueError("AI:n returnerade inte ett scenario-objekt")

    scenario = Scenario(
        name=_slug(str(data.get("name", "generated-scenario"))),
        description=str(data.get("description", description))[:300],
        steps=[TestStep(**step) for step in data.get("steps", []) if isinstance(step, dict)],
    )
    if not scenario.steps:
        raise ValueError("AI:n skapade inga teststeg")

    root = Path(__file__).resolve().parent.parent
    destination = Path(out_path) if out_path else root / "scenarios" / f"{scenario.name}.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    scenario.save(destination)
    return destination
