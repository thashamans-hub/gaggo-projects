"""Seeded random-walk fuzzing with anomaly detection."""
from __future__ import annotations

import json
import logging
import random
from datetime import datetime
from pathlib import Path

import pyautogui

from config import Config
from core.browser_bridge import BrowserBridge
from core.commands import parse_plan
from core.executor import Executor
from core.verify import Verifier, is_black
from game.tft_tester import StepResult, TestReport
from ui.report import save_html

log = logging.getLogger("ai-control.fuzzer")

BASE_ACTIONS: list[dict] = [
    {"action": "press", "key": "1"},
    {"action": "press", "key": "2"},
    {"action": "press", "key": "3"},
    {"action": "press", "key": "4"},
    {"action": "press", "key": "5"},
    {"action": "press", "key": "6"},
    {"action": "press", "key": "f5"},
    {"action": "press", "key": "enter"},
    {"action": "press", "key": "esc"},
    {"action": "wait", "seconds": 0.2},
]


class Fuzzer:
    def __init__(
        self,
        config: Config,
        executor: Executor,
        verifier: Verifier,
        bridge: BrowserBridge | None = None,
    ) -> None:
        self.config = config
        self.executor = executor
        self.verifier = verifier
        self.bridge = bridge

    def _random_click(self, rng: random.Random) -> dict:
        width, height = pyautogui.size()
        return {
            "action": "click",
            "x": rng.randint(int(width * 0.25), int(width * 0.75)),
            "y": rng.randint(int(height * 0.25), int(height * 0.75)),
        }

    def run(self, iterations: int, seed: int | None = None) -> TestReport:
        seed = self.config.fuzz_seed if seed is None else seed
        rng = random.Random(seed)
        report = TestReport(scenario=f"fuzz-{seed}", description=f"{iterations} seedade slumpsteg")
        started = datetime.now()
        log.info("Startar fuzz: %d steg, seed=%d", iterations, seed)

        for index in range(max(1, iterations)):
            actions = [rng.choice(BASE_ACTIONS) for _ in range(rng.randint(1, 5))]
            if rng.random() < 0.35:
                actions.insert(rng.randint(0, len(actions)), self._random_click(rng))
            result = StepResult(name=f"fuzz #{index + 1}", command=json.dumps(actions, ensure_ascii=False))
            try:
                plan = parse_plan({"actions": actions, "risk": "low"})
                result.actions_run = self.executor.run(plan)
                frozen, ratio = self.verifier.is_frozen(0.3)
                result.frozen = frozen
                try:
                    result.black = is_black(pyautogui.screenshot().convert("RGB"))
                except Exception:
                    result.black = False
                console = self.bridge.errors() if self.bridge and self.bridge.connected else []
                detail_parts = []
                if frozen:
                    detail_parts.append(f"fryst skärm (diff {ratio:.4f})")
                if result.black:
                    detail_parts.append("blackscreen")
                if console:
                    detail_parts.append(f"{len(console)} console-fel")
                passed = not detail_parts
                result.verification = {
                    "condition": "Inga anomalier (frysning, blackscreen, console-fel)",
                    "passed": passed,
                    "detail": "; ".join(detail_parts) or "inga anomalier",
                    "evidence": f"seed={seed}, steg={index + 1}",
                }
            except Exception as exc:
                result.error = str(exc)
            report.results.append(result)

        report.finished_at = datetime.now().isoformat(timespec="seconds")
        report.duration_s = (datetime.now() - started).total_seconds()
        report.console_errors = self.bridge.errors() if self.bridge and self.bridge.connected else []

        folder = self.config.reports_dir
        root = Path(__file__).resolve().parent.parent / folder
        target = root / f"fuzz-{seed}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        target.mkdir(parents=True, exist_ok=True)
        (target / "report.json").write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        save_html(report, target / "report.html", [], [], None, gif="")
        report.json_path = str(target / "report.json")
        report.html_path = str(target / "report.html")
        log.info("Fuzz klart: %s", report.summary())
        return report
