"""Rules that must always hold in Squadron TD's authoritative state."""
from __future__ import annotations

from typing import Any

PHASES = {"Lobby", "BuildPhase", "CombatPhase", "RoundEndPhase", "GameOver", None}


def check_invariants(state: dict[str, Any] | None) -> list[str]:
    """Return a list of human-readable violations. Empty list means healthy."""
    if not state:
        return []

    problems: list[str] = []

    def non_negative(key: str, label: str) -> None:
        value = state.get(key)
        if value is not None and value < 0:
            problems.append(f"{label} är negativt ({value})")

    non_negative("minerals", "Mineraler")
    non_negative("gas", "Gas")
    non_negative("supplyUsed", "Använd supply")
    non_negative("towers", "Antal torn")
    non_negative("kills", "Kills")
    non_negative("leaks", "Leaks")

    used, maximum = state.get("supplyUsed"), state.get("supplyMax")
    if used is not None and maximum is not None and used > maximum:
        problems.append(f"Supply överskriden ({used}/{maximum})")

    hp, max_hp = state.get("ssHp"), state.get("ssMaxHp")
    if hp is not None and max_hp is not None:
        if hp < 0:
            problems.append("Security System HP är negativt")
        if hp > max_hp + 0.01:
            problems.append(f"Security System HP över max ({hp}/{max_hp})")

    wave = state.get("wave")
    if wave is not None and not (1 <= wave <= 31):
        problems.append(f"Våg utanför intervallet 1–31 ({wave})")

    if state.get("phase") not in PHASES:
        problems.append(f"Okänd fas ({state.get('phase')})")

    speed = state.get("speed")
    if speed is not None and speed not in {1, 2}:
        problems.append(f"Hastighet är inte 1x/2x ({speed})")

    tick = state.get("gasTickAcc")
    if tick is not None and not (0 <= tick < 1.5):
        problems.append(f"Gas-tick-ackumulator ur intervall ({tick})")

    return problems
