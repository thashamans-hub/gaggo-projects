"""Run one scenario across a matrix of game configurations."""
from __future__ import annotations

import itertools
import json
import logging
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from game.scenarios import Scenario
from game.tft_tester import ScenarioRunner, TestReport
from ui.report import build_html

log = logging.getLogger("ai-control.matrix")

BUILDERS = [
    "ghost", "elemental", "beast", "mechanical", "nature", "shadow",
    "celestial", "ancient", "automaton", "soul", "sylphy", "chaos",
]
DIFFICULTIES = ["Casual", "Normal", "Hard", "Brutal"]
MUTATORS = ["none", "glass", "capitalism", "miniboss", "shared", "bonanza", "overdrive"]

MATRICES: dict[str, dict[str, list[str]]] = {
    "builders": {"builder": BUILDERS},
    "difficulty": {"difficulty": DIFFICULTIES},
    "mutators": {"mutator": MUTATORS},
    "quick": {"builder": ["ghost", "elemental", "beast"], "difficulty": ["Normal", "Hard"]},
}


def substitute(text: str, variables: dict[str, str]) -> str:
    for key, value in variables.items():
        text = text.replace("{" + key + "}", value)
    return text


def materialize(scenario: Scenario, variables: dict[str, str]) -> Scenario:
    copy = deepcopy(scenario)
    suffix = ",".join(f"{k}={v}" for k, v in variables.items())
    copy.name = f"{scenario.name}@{suffix}"
    copy.description = f"{scenario.description} — {suffix}"
    for step in copy.steps:
        step.name = substitute(step.name, variables) + f" [{suffix}]"
        step.command = substitute(step.command, variables)
        step.expect = substitute(step.expect, variables)
        step.expect_state = substitute(step.expect_state, variables)
    return copy


@dataclass
class MatrixResult:
    name: str
    budget: int
    combinations: list[dict[str, str]] = field(default_factory=list)
    reports: list[TestReport] = field(default_factory=list)
    summary_path: str = ""
    html_path: str = ""

    @property
    def passed(self) -> bool:
        return all(report.passed for report in self.reports) and bool(self.reports)

    def summary(self) -> str:
        ok = sum(1 for report in self.reports if report.passed)
        return f"{'PASS' if self.passed else 'FAIL'} matris {self.name}: {ok}/{len(self.reports)} körningar"


class MatrixRunner:
    def __init__(self, runner: ScenarioRunner, budget: int = 24, reports_root: Path | None = None) -> None:
        self.runner = runner
        self.budget = max(1, budget)
        self.reports_root = reports_root or runner.reports_root

    def combinations(self, name: str) -> list[dict[str, str]]:
        variables = MATRICES.get(name)
        if variables is None:
            raise KeyError(f"Okänd matris: {name}. Tillgängliga: {', '.join(MATRICES)}")
        keys = list(variables)
        values = [variables[key] for key in keys]
        result = []
        for combination in itertools.product(*values):
            result.append(dict(zip(keys, combination)))
            if len(result) >= self.budget:
                break
        return result

    def run(self, scenario: Scenario, matrix_name: str) -> MatrixResult:
        combinations = self.combinations(matrix_name)
        result = MatrixResult(name=matrix_name, budget=self.budget, combinations=combinations)
        log.info("Startar matris %s med %d kombinationer", matrix_name, len(combinations))

        for variables in combinations:
            report = self.runner.run(materialize(scenario, variables))
            result.reports.append(report)

        folder = self.reports_root / f"matrix-{matrix_name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        folder.mkdir(parents=True, exist_ok=True)
        summary_path = folder / "summary.json"
        summary_path.write_text(
            json.dumps(
                {
                    "matrix": matrix_name,
                    "budget": self.budget,
                    "passed": result.passed,
                    "combinations": combinations,
                    "runs": [
                        {
                            "scenario": report.scenario,
                            "passed": report.passed,
                            "html": report.html_path,
                            "summary": report.summary(),
                        }
                        for report in result.reports
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        combined = TestReport(scenario=f"matrix-{matrix_name}")
        combined.results = [
            step for report in result.reports for step in report.results
        ]
        html_path = folder / "summary.html"
        html_path.write_text(build_html(combined.to_dict(), [], [], gif=""), encoding="utf-8")
        result.summary_path = str(summary_path)
        result.html_path = str(html_path)
        log.info(result.summary())
        return result
