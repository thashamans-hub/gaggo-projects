"""QA scenarios for Squadron TD (plus a few generic ones). Add your own in this format."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class TestStep:
    name: str
    command: str = ""  # given to the AI planner; empty when assert_only
    expect: str = ""  # vision assertion checked afterwards; empty = skip
    expect_state: str = ""  # JS expression via CDP, must return true; empty = skip
    repeat: int = 1  # run this step N times
    assert_only: bool = False  # skip the planner, only verify the current screen
    capture: bool = True  # save a screenshot of the resulting screen

    def __post_init__(self) -> None:
        self.repeat = max(1, min(50, int(self.repeat)))


@dataclass
class Scenario:
    name: str
    description: str
    steps: list[TestStep] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def load(path: str | Path) -> "Scenario":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return Scenario(
            name=data.get("name", Path(path).stem),
            description=data.get("description", ""),
            steps=[TestStep(**step) for step in data.get("steps", [])],
        )


BUILT_IN: list[Scenario] = [
    Scenario(
        name="squadron-smoke",
        description="Squadron TD: lobbyn syns, ett spel kan startas, byggfasen visas.",
        steps=[
            TestStep("Lobbyn syns", "Titta på skärmen och beskriv lobbyn. Gör ingenting.",
                     "Squadron TD-lobbyn visas med builder-val, mutatorer, svårighet och Start-knapp.",
                     expect_state="document.body && document.body.innerText.length > 200"),
            TestStep("Starta matchen", "Välj en builder och klicka Start Game.",
                     "Spelet är i byggfasen: arena, HUD med mineraler/gas och byggruta syns."),
            TestStep("Pausa och återuppta", "Tryck Esc för att pausa och sedan igen för att återuppta.",
                     "Paus-overlayen visades och försvann; spelet är tillbaka i byggfasen."),
        ],
    ),
    Scenario(
        name="squadron-build",
        description="Placera, upgrade och sälj torn; kontrollera resurser.",
        steps=[
            TestStep("Välj tornnivå", "Tryck 1 för att välja tornnivå 1.",
                     "HUD:en visar att tornnivå 1 är vald."),
            TestStep("Placera torn", "Klicka på en ledig ruta i byggruten för att placera tornet.",
                     "Ett torn står på rutan och mineralerna har minskat."),
            TestStep("Uppgradera torn", "Klicka på tornet du just placerade för att uppgradera det.",
                     "Tornet visar en högre nivå eller uppgradering, och mineralerna har minskat igen."),
            TestStep("Sälj torn", "Högerklicka på tornet för att sälja det.",
                     "Tornet är borttaget och mineralerna har ökat (50% återbetalning)."),
        ],
    ),
    Scenario(
        name="squadron-economy",
        description="Ekonomikontroller: W, G, S, A.",
        steps=[
            TestStep("Köp arbetare", "Tryck W för att köpa en arbetare.",
                     "Antalet arbetare har ökat eller mineralerna har minskat."),
            TestStep("Gasflöde", "Tryck G för att uppgradera gasflödet.",
                     "Gasnivån eller gasflödesindikatorn har ändrats."),
            TestStep("Arbetarhastighet", "Tryck S för att uppgradera arbetarnas hastighet.",
                     "HUD:en visar en uppgradering av arbetarhastigheten."),
            TestStep("Försörjning", "Tryck A för att uppgradera supply.",
                     "Supply-gränsen har ökat och resurserna har minskat."),
        ],
    ),
    Scenario(
        name="squadron-combat",
        description="Bygg, starta våg och kontrollera att torn blir fighters.",
        steps=[
            TestStep("Bygg försvar", "Välj tornnivå 1 och placera tre torn i byggruten.",
                     "Tre torn står i byggruten."),
            TestStep("Starta vågen", "Tryck Enter för att starta vågen direkt.",
                     "Spelet är i stridsfasen och fiender rör sig mot Security System."),
            TestStep("Fighters syns", "Vänta två sekunder och titta på arenan.",
                     "Tornen har blivit AI-fighters som skjuter mot fiender; HUD:en visar pågående våg."),
            TestStep("Vågen avslutas", "Vänta tills vågen är klar och byggfasen återvänder.",
                     "Spelet är tillbaka i byggfasen för nästa våg, utan att ha fastnat."),
        ],
    ),
    Scenario(
        name="squadron-settings",
        description="F5, M, H, hastighet och statistik.",
        steps=[
            TestStep("Targeting priority", "Tryck F5 en gång för att byta targeting-priority.",
                     "HUD:en visar ett annat targeting-läge."),
            TestStep("Mute", "Tryck M för att stänga av ljudet.",
                     "Ljudindikatorn i toppfältet visar att ljudet är avstängt."),
            TestStep("Hjälp", "Tryck H för att öppna hjälpen.",
                     "Hjälp-overlayen med kontroller visas."),
            TestStep("Stäng hjälp", "Tryck H igen för att stänga hjälpen.",
                     "Hjälp-overlayen är borta."),
            TestStep("Statistik", "Klicka på statistik-knappen i toppfältet.",
                     "Statistikmodalen med diagram och tabell visas."),
        ],
    ),
    Scenario(
        name="squadron-edge",
        description="Kantfall: ogiltig ruta, för lite resurser, snabba tangenttryck.",
        steps=[
            TestStep("Ogiltig placering", "Försök placera ett torn utanför byggruten.",
                     "Inget torn placeras utanför rutnätet och spelet har inte fryst."),
            TestStep("Snabba tier-byten", "Tryck 1,2,3,4,5,6 snabbt i följd.",
                     "Spelet svarar fortfarande och en tornnivå är vald."),
            TestStep("Uppgradera utan resurser", "Försök uppgradera ett torn när mineralerna kanske inte räcker.",
                     "Ingen krasch; antingen uppgraderas tornet eller så visas tydlig feedback."),
        ],
    ),
    Scenario(
        name="squadron-soak",
        description="Långkörning med repetina åtgärder för att hitta frysningar.",
        steps=[
            TestStep("Upprepa tier-val", "Tryck siffrorna 1 till 6 tio gånger.",
                     "Spelet är responsivt och HUD:en är synlig utan felmeddelande.", repeat=10),
            TestStep("Starta och spela våg", "Tryck Enter och låt vågen pågå i fem sekunder.",
                     "Vågen pågår utan frysning, blackscreen eller felruta."),
            TestStep("Ingen frysning", "", "Skärmen uppdateras fortfarande och spelet är inte fryst.",
                     assert_only=True),
        ],
    ),
    # Generiska fall bakåtkompatibilitet
    Scenario(
        name="smoke",
        description="Grundkoll: spelet syns och en enkel åtgärd fungerar.",
        steps=[
            TestStep("Spelet syns", "Beskriv vad du ser. Gör ingenting.", "Spelgränssnittet är synligt."),
        ],
    ),
    Scenario(
        name="soak",
        description="Upprepade operationer.",
        steps=[
            TestStep("Upprepad åtgärd", "Tryck F5 fem gånger.", "Spelet svarar fortfarande.", repeat=5),
        ],
    ),
]


def get_scenario(name: str) -> Scenario | None:
    for scenario in BUILT_IN:
        if scenario.name.lower() == name.lower():
            return scenario
    return None
