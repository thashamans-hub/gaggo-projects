"""Runs scripted QA scenarios and produces JSON + HTML reports with rich evidence."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

import pyautogui
from PIL import Image

from config import Config
from core import context as screen_context
from core.baseline import BaselineManager
from core.browser_bridge import BrowserBridge
from core.brain import Planner
from core.executor import Executor
from core.game_probe import GameProbe
from core.metrics import metrics
from core.recorder import FrameRecorder
from core.verify import Verifier, is_black
from core.webhook import notify as notify_webhook
from core.window import focus_game_window
from game.invariants import check_invariants
from game.scenarios import Scenario
from ui.report import save_html, save_index

log = logging.getLogger("ai-control.tester")


@dataclass
class StepResult:
    name: str
    command: str
    thought: str = ""
    observation: str = ""
    actions_run: int = 0
    verification: dict | None = None
    state_check: dict | None = None
    state: dict | None = None
    state_violations: list[str] = field(default_factory=list)
    baseline: dict | None = None
    error: str = ""
    duration_s: float = 0.0
    frozen: bool = False
    black: bool = False
    screenshot: str = ""
    repeat: int = 1

    @property
    def passed(self) -> bool:
        if self.error:
            return False
        if self.state_check and self.state_check.get("passed") is False:
            return False
        if self.state_violations:
            return False
        if self.baseline and self.baseline.get("passed") is False:
            return False
        if self.verification is None:
            return True  # no assertion = the step didn't crash
        return bool(self.verification.get("passed"))


@dataclass
class TestReport:
    scenario: str
    description: str = ""
    started_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    finished_at: str = ""
    duration_s: float = 0.0
    results: list[StepResult] = field(default_factory=list)
    json_path: str = ""
    html_path: str = ""
    gif: str = ""
    console_errors: list[dict] = field(default_factory=list)
    console_all: list[dict] = field(default_factory=list)
    dom_before: str = ""
    dom_after: str = ""
    perf: dict = field(default_factory=dict)
    state_snapshots: list[dict] = field(default_factory=list)
    invariant_violations: list[str] = field(default_factory=list)
    fail_on_console_error: bool = True
    fail_on_invariant: bool = True

    @property
    def passed(self) -> bool:
        steps_ok = all(result.passed for result in self.results) and bool(self.results)
        console_ok = not (self.fail_on_console_error and self.console_errors)
        invariant_ok = not (self.fail_on_invariant and self.invariant_violations)
        return steps_ok and console_ok and invariant_ok

    def to_dict(self) -> dict:
        data = asdict(self)
        data["passed"] = self.passed
        return data

    def summary(self) -> str:
        ok = sum(1 for r in self.results if r.passed)
        extra = f" | {len(self.console_errors)} console-fel" if self.console_errors else ""
        return f"{'PASS' if self.passed else 'FAIL'}  {self.scenario}: {ok}/{len(self.results)} steg{extra}"


class ScenarioRunner:
    def __init__(
        self,
        config: Config,
        planner: Planner,
        executor: Executor,
        verifier: Verifier,
        on_progress: Callable[[str], None] | None = None,
        bridge: BrowserBridge | None = None,
        on_failure: Callable[[str], None] | None = None,
        probe: GameProbe | None = None,
        baseline: BaselineManager | None = None,
        save_baselines: bool = False,
    ) -> None:
        self.config = config
        self.probe = probe
        self.baseline = baseline
        self.save_baselines = save_baselines
        self.planner = planner
        self.executor = executor
        self.verifier = verifier
        self.on_progress = on_progress
        self.on_failure = on_failure
        self.bridge = bridge
        self.reports_root = Path(__file__).resolve().parent.parent / config.reports_dir
        self.reports_root.mkdir(parents=True, exist_ok=True)

    def _progress(self, message: str) -> None:
        log.info(message)
        if self.on_progress:
            self.on_progress(message)

    def _capture(self, folder: Path, name: str) -> tuple[str, bool, Image.Image | None]:
        if not self.config.capture_screenshots:
            return "", False, None
        try:
            image = pyautogui.screenshot().convert("RGB")
            black = is_black(image)
            image.thumbnail((960, 540), Image.LANCZOS)
            path = folder / f"{name}.jpg"
            image.save(path, quality=72)
            return str(path), black, image
        except Exception as exc:
            log.warning("Kunde inte spara skärmbild: %s", exc)
            return "", False, None

    def run(self, scenario: Scenario) -> TestReport:
        started = time.perf_counter()
        report = TestReport(
            scenario=scenario.name,
            description=scenario.description,
            fail_on_console_error=self.config.fail_on_console_error,
        )
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        folder = self.reports_root / f"{scenario.name}-{stamp}"
        folder.mkdir(parents=True, exist_ok=True)
        screenshots: list[str | None] = []
        frozen_flags: list[bool] = []
        recorder = FrameRecorder(self.config.gif_recording, self.config.gif_fps, self.config.gif_width)
        recorder.add()

        bridge = self.bridge
        if bridge and bridge.enabled:
            bridge.connect()
            bridge.clear()
            try:
                report.dom_before = bridge.dom_text()
            except Exception:
                pass

        focused = focus_game_window(self.config, bridge)
        if focused:
            self._progress(f"Fokuserade: {focused}")

        self._progress(f"Startar testscenario: {scenario.name}")

        for step in scenario.steps:
            for iteration in range(step.repeat):
                label = step.name if step.repeat == 1 else f"{step.name} ({iteration + 1}/{step.repeat})"
                self._progress(f"  Steg: {label}")
                result = StepResult(name=label, command=step.command, repeat=step.repeat)
                step_started = time.perf_counter()
                try:
                    if not step.assert_only and step.command.strip():
                        screen = screen_context.collect(self.config.include_screenshot)
                        plan = self.planner.plan(step.command, screen, hint=step.expect)
                        result.thought = plan.thought
                        result.observation = plan.observation
                        for error in plan.errors:
                            log.warning("Planfel i '%s': %s", step.name, error)
                        result.actions_run = self.executor.run(plan)

                    if step.expect:
                        after = screen_context.collect(self.config.include_screenshot)
                        verification = self.verifier.check(step.expect, after)
                        result.verification = {
                            "condition": verification.condition,
                            "passed": verification.passed,
                            "detail": verification.detail,
                            "evidence": verification.evidence,
                        }
                        self._progress(f"    {'PASS' if verification.passed else 'FAIL'}: {verification.detail}")

                    if step.expect_state:
                        if bridge and bridge.connected:
                            try:
                                value = bridge.evaluate(step.expect_state)
                                result.state_check = {
                                    "expression": step.expect_state,
                                    "passed": bool(value),
                                    "value": value,
                                }
                                self._progress(f"    State: {'PASS' if value else 'FAIL'} {step.expect_state[:70]}")
                            except Exception as exc:
                                result.state_check = {
                                    "expression": step.expect_state,
                                    "passed": False,
                                    "error": str(exc),
                                }
                        else:
                            result.state_check = {"expression": step.expect_state, "skipped": True}

                    result.screenshot, result.black, shot_image = self._capture(
                        folder, f"step-{len(report.results) + 1:02d}"
                    )
                    if result.black:
                        self._progress("    ⚠ Blackscreen upptäckt")

                    if self.probe:
                        result.state = self.probe.read()
                        if result.state:
                            result.state_violations = check_invariants(result.state)
                            report.state_snapshots.append(result.state)
                            if result.state_violations:
                                self._progress(f"    ⚠ Invariant: {result.state_violations[0]}")

                    if self.baseline and shot_image is not None:
                        if self.save_baselines:
                            self.baseline.save(scenario.name, label, shot_image)
                            result.baseline = {"saved": True}
                        else:
                            result.baseline = self.baseline.check(scenario.name, label, shot_image)
                            if result.baseline.get("passed") is False:
                                self._progress(
                                    f"    ⚠ Visuell regression {result.baseline.get('diff')}"
                                )

                    recorder.add()

                    if self.config.frozen_detection:
                        was_frozen, ratio = self.verifier.is_frozen()
                        result.frozen = was_frozen
                        if was_frozen:
                            self._progress(f"    ⚠ Fryst skärm misstänkt (bilddiff {ratio:.4f})")

                except Exception as exc:
                    log.exception("Steg '%s' misslyckades", step.name)
                    result.error = str(exc)
                    metrics.record_error(f"Steg {step.name}: {exc}")
                    if self.on_failure:
                        self.on_failure(f"Steg {step.name} misslyckades")

                result.duration_s = round(time.perf_counter() - step_started, 2)
                report.results.append(result)
                screenshots.append(result.screenshot or None)
                frozen_flags.append(result.frozen)

                if self.config.test_delay > 0 and step is not scenario.steps[-1]:
                    time.sleep(self.config.test_delay)

        if bridge and bridge.connected:
            report.console_all = bridge.drain()
            report.console_errors = bridge.errors()
            try:
                report.dom_after = bridge.dom_text()
            except Exception:
                pass
            try:
                report.perf = bridge.metrics()
            except Exception:
                pass

        report.finished_at = datetime.now().isoformat(timespec="seconds")
        report.duration_s = round(time.perf_counter() - started, 2)
        report.gif = recorder.save(folder / "run.gif")

        json_path = folder / "report.json"
        json_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        html_path = folder / "report.html"
        save_html(report, html_path, screenshots, frozen_flags, metrics.snapshot(), gif=report.gif)
        report.json_path = str(json_path)
        report.html_path = str(html_path)
        save_index(self.reports_root)

        report.invariant_violations = sorted(
            {violation for result in report.results for violation in result.state_violations}
        )
        notify_webhook(
            self.config,
            {
                "scenario": report.scenario,
                "passed": report.passed,
                "summary": report.summary(),
                "html": report.html_path,
                "console_errors": len(report.console_errors),
                "invariant_violations": report.invariant_violations,
            },
        )

        passed_count = sum(1 for r in report.results if r.passed)
        metrics.record_test(passed_count, len(report.results) - passed_count)
        self._progress(f"Klart: {report.summary()} → {html_path}")
        return report
