"""Global hotkeys and push-to-talk built on pynput."""
from __future__ import annotations

import logging
import threading
from collections.abc import Callable

from pynput import keyboard

log = logging.getLogger("ai-control.hotkeys")

SPECIAL = {
    keyboard.Key.ctrl: "<ctrl>",
    keyboard.Key.ctrl_l: "<ctrl>",
    keyboard.Key.ctrl_r: "<ctrl>",
    keyboard.Key.shift: "<shift>",
    keyboard.Key.shift_l: "<shift>",
    keyboard.Key.shift_r: "<shift>",
    keyboard.Key.alt: "<alt>",
    keyboard.Key.alt_l: "<alt>",
    keyboard.Key.alt_gr: "<alt_gr>",
    keyboard.Key.cmd: "<win>",
    keyboard.Key.cmd_l: "<win>",
    keyboard.Key.cmd_r: "<win>",
    keyboard.Key.space: "<space>",
    keyboard.Key.enter: "<enter>",
    keyboard.Key.esc: "<esc>",
    keyboard.Key.tab: "<tab>",
    keyboard.Key.backspace: "<backspace>",
    keyboard.Key.delete: "<delete>",
}


def _normalize(key) -> str | None:
    if key in SPECIAL:
        return SPECIAL[key]
    if isinstance(key, keyboard.KeyCode):
        if key.char:
            return key.char.lower()
        return None
    return None


class HotkeyManager:
    """Fires callbacks on key combos; supports a hold-key for push-to-talk."""

    def __init__(self) -> None:
        self._bindings: dict[frozenset[str], Callable[[], None]] = {}
        self._pressed: set[str] = set()
        self._down_callback: Callable[[], None] | None = None
        self._up_callback: Callable[[], None] | None = None
        self._hold_key: str | None = None
        self._hold_active = False
        self._listener: keyboard.Listener | None = None
        self._lock = threading.Lock()

    def bind(self, combo: str, callback: Callable[[], None]) -> None:
        keys = frozenset(part.strip().lower() for part in combo.split("+") if part.strip())
        self._bindings[keys] = callback
        log.info("Genväg bundet: %s", combo)

    def bind_hold(self, combo: str, on_down: Callable[[], None], on_up: Callable[[], None]) -> None:
        keys = [part.strip().lower() for part in combo.split("+") if part.strip()]
        self._hold_key = keys[-1] if keys else None
        self._hold_combo = frozenset(keys)
        self._down_callback = on_down
        self._up_callback = on_up
        log.info("Push-to-talk bundet: %s", combo)

    def start(self) -> None:
        self._listener = keyboard.Listener(on_press=self._on_press, on_release=self._on_release)
        self._listener.start()

    def stop(self) -> None:
        if self._listener:
            self._listener.stop()

    def _on_press(self, key) -> None:
        name = _normalize(key)
        if not name:
            return
        with self._lock:
            is_new = name not in self._pressed
            self._pressed.add(name)

        if self._hold_key and name == self._hold_key and is_new:
            if self._hold_combo.issubset(self._pressed):
                self._hold_active = True
                self._safe_call(self._down_callback)
            return

        if is_new:
            for combo, callback in self._bindings.items():
                if combo.issubset(self._pressed):
                    self._safe_call(callback)

    def _on_release(self, key) -> None:
        name = _normalize(key)
        if not name:
            return
        with self._lock:
            self._pressed.discard(name)

        if self._hold_key and name == self._hold_key and self._hold_active:
            self._hold_active = False
            self._safe_call(self._up_callback)
            # Let show/hide hotkeys re-trigger cleanly after push-to-talk.

    @staticmethod
    def _safe_call(callback: Callable[[], None] | None) -> None:
        if callback is None:
            return
        try:
            threading.Thread(target=callback, daemon=True).start()
        except Exception as exc:
            log.error("Genvägs_callback misslyckades: %s", exc)
