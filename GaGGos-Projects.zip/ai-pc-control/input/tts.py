"""Spoken feedback via Windows System.Speech (no extra Python dependencies)."""
from __future__ import annotations

import logging
import subprocess

log = logging.getLogger("ai-control.tts")


def _escape(text: str) -> str:
    return text.replace("'", "''")


class Speaker:
    def __init__(self, enabled: bool = True, voice: str = "") -> None:
        self.enabled = enabled
        self.voice = voice

    def say(self, message: str) -> None:
        if not self.enabled or not message.strip():
            return
        try:
            voice_line = ""
            if self.voice:
                voice_line = (
                    "$match = $s.GetInstalledVoices() | Where-Object {$_.VoiceInfo.Name -like '"
                    + _escape(self.voice)
                    + "'} | Select-Object -First 1; "
                    "if ($match) { $s.Voice = $match.VoiceInfo }; "
                )
            script = (
                "Add-Type -AssemblyName System.Speech; "
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                + voice_line
                + f"$s.Speak('{_escape(message[:300])}'); $s.Dispose()"
            )
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.Popen(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                creationflags=flags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception as exc:
            log.debug("TTS misslyckades: %s", exc)
