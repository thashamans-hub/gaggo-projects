"""Push-to-talk audio capture + speech-to-text (local Whisper or Google)."""
from __future__ import annotations

import io
import logging
import threading
import wave
from collections.abc import Callable

import numpy as np
import sounddevice as sd

from config import Config

log = logging.getLogger("ai-control.voice")

SAMPLE_RATE = 16_000


def _float32_to_wav(audio: np.ndarray, samplerate: int = SAMPLE_RATE) -> bytes:
    pcm = (np.clip(audio, -1.0, 1.0) * 32767).astype(np.int16)
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(samplerate)
        wav.writeframes(pcm.tobytes())
    return buffer.getvalue()


class VoiceInput:
    def __init__(self, config: Config, on_transcript: Callable[[str], None]) -> None:
        self.config = config
        self.on_transcript = on_transcript
        self._frames: list[np.ndarray] = []
        self._recording = False
        self._stream: sd.InputStream | None = None
        self._model = None
        self._lock = threading.Lock()

    def _load_model(self) -> None:
        if self._model is not None:
            return
        from faster_whisper import WhisperModel

        log.info("Laddar lokal Whisper-modell '%s' (kan ta en stund första gången)...", self.config.whisper_model)
        self._model = WhisperModel(self.config.whisper_model, device="cpu", compute_type="int8")

    def start(self) -> None:
        if self._recording:
            return
        if self.config.stt_backend == "local":
            try:
                self._load_model()
            except Exception as exc:
                log.error("Kunde inte ladda Whisper: %s", exc)
                self.on_transcript("")
                return
        with self._lock:
            self._frames = []
            self._recording = True
        self._stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            callback=self._on_audio,
        )
        self._stream.start()

    def _on_audio(self, indata: np.ndarray, frames: int, time_info, status) -> None:
        if status:
            log.warning("Ljudstatus: %s", status)
        if self._recording:
            self._frames.append(indata.copy())

    def stop(self) -> None:
        if not self._recording:
            return
        self._recording = False
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None

        with self._lock:
            frames = list(self._frames)
            self._frames = []
        audio = np.concatenate(frames, axis=0).flatten() if frames else np.empty(0, dtype="float32")

        if audio.size < SAMPLE_RATE // 5:  # < 0.2 s
            log.info("För kort ljudprov, ignoreras.")
            self.on_transcript("")
            return

        try:
            text = self._transcribe(audio).strip()
        except Exception as exc:
            log.error("Transkribering misslyckades: %s", exc)
            text = ""
        self.on_transcript(text)

    def _transcribe(self, audio: np.ndarray) -> str:
        if self.config.stt_backend == "local":
            segments, _ = self._model.transcribe(
                audio,
                language=self.config.language or None,
                beam_size=5,
                vad_filter=True,
            )
            return "".join(segment.text for segment in segments)

        import speech_recognition as sr

        recognizer = sr.Recognizer()
        audio_data = sr.AudioData(_float32_to_wav(audio), SAMPLE_RATE, 2)
        language = "sv-SE" if self.config.language.startswith("sv") else self.config.language or "en-US"
        return recognizer.recognize_google(audio_data, language=language)
