"""AI PC Control — QA Copilot Pro. Background app with voice, text and game testing."""
from __future__ import annotations

import argparse
import logging
import os
import sys
import threading
import webbrowser
from dataclasses import replace
from pathlib import Path

# First run: create .env from the template before config imports it.
_env = Path(__file__).with_name(".env")
if not _env.exists():
    _example = _env.with_name(".env.example")
    if _example.exists():
        _env.write_text(_example.read_text(encoding="utf-8"), encoding="utf-8")

from config import Config  # noqa: E402
from core import context  # noqa: E402
from core.baseline import BaselineManager  # noqa: E402
from core.browser_bridge import BrowserBridge  # noqa: E402
from core.brain import build_planner  # noqa: E402
from core.executor import Executor  # noqa: E402
from core.game_probe import GameProbe  # noqa: E402
from core.metrics import metrics  # noqa: E402
from core.state import StateStore  # noqa: E402
from core.verify import Verifier  # noqa: E402
from game.author import author_scenario  # noqa: E402
from game.fuzzer import Fuzzer  # noqa: E402
from game.matrix import MATRICES, MatrixRunner  # noqa: E402
from game.scenarios import BUILT_IN, Scenario, get_scenario  # noqa: E402
from game.tft_tester import ScenarioRunner  # noqa: E402
from input.hotkeys import HotkeyManager  # noqa: E402
from input.tts import Speaker  # noqa: E402
from input.voice import VoiceInput  # noqa: E402
from ui.dashboard import Dashboard  # noqa: E402
from ui.overlay import Overlay  # noqa: E402


def setup_logging(config: Config) -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if config.log_file:
        handlers.append(logging.FileHandler(Path(__file__).with_name(config.log_file), encoding="utf-8"))
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
    )


def make_icon():
    from PIL import Image, ImageDraw

    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((4, 4, 60, 60), fill=(88, 101, 242, 255))
    draw.polygon([(24, 16), (24, 48), (32, 40), (39, 52), (45, 49), (38, 37), (49, 36)], fill=(255, 255, 255, 255))
    return image


def main(config: Config | None = None) -> None:
    config = config or Config()
    setup_logging(config)
    log = logging.getLogger("ai-control")
    log.info("Startar AI PC Control Pro (spel=%s, leverantör=%s)", config.game_name, config.provider)

    overlay = Overlay()
    state = StateStore(config)
    speaker = Speaker(config.tts_enabled, config.tts_voice)
    overlay.set_history([entry["command"] for entry in state.recent_history(100)])

    planner = None
    try:
        planner = build_planner(config, game_mode=config.game_mode)
    except Exception as exc:
        log.error("Kunde inte initiera AI-leverantör: %s", exc)
        metrics.record_error(str(exc))

    processing = threading.Lock()
    verifier = Verifier(config)
    bridge = BrowserBridge(config)
    probe = GameProbe(config, bridge)
    baseline = BaselineManager(config, Path(__file__).resolve().parent)

    def set_status(text: str, busy: bool | None = None) -> None:
        overlay.set_status(text, busy=bool(busy) if busy is not None else False)
        state.set(text, busy)

    def check_screen(condition: str) -> bool:
        try:
            return verifier.check(condition).passed
        except Exception as exc:
            log.error("Verifiering misslyckades: %s", exc)
            return False

    def handle_command(text: str, source: str = "text") -> None:
        text = (text or "").strip()
        if not text:
            return
        if not processing.acquire(blocking=False):
            set_status("Redan igång – vänta ett ögonblick", busy=True)
            return
        try:
            metrics.record_command()
            state.add_command(text, source)
            if state.paused:
                set_status("Pausad – kommando ignorerat", busy=True)
                return
            set_status("Tänker...", busy=True)
            if planner is None:
                set_status("AI inte konfigurerad – kontrollera .env och loggen", busy=True)
                speaker.say("AI:n är inte konfigurerad.")
                return

            screen = context.collect(config.include_screenshot)
            plan = planner.plan(text, screen)
            for error in plan.errors:
                log.warning("Planfel: %s", error)
            if plan.observation:
                log.info("Observation: %s", plan.observation)
            if not plan.actions:
                message = plan.observation or plan.thought or "Inga åtgärder att köra"
                set_status(message[:100], busy=False)
                speaker.say(message[:120])
                return

            count = executor.run(plan)
            suffix = f" – {plan.observation[:70]}" if plan.observation else ""
            message = f"Klart – {count} åtgärd(er){suffix}"
            set_status(message, busy=False)
            speaker.say(f"Klart. {count} åtgärder.")
        except Exception as exc:
            log.exception("Fel vid kommando: %s", exc)
            metrics.record_error(str(exc))
            set_status(f"Fel: {exc}", busy=True)
            speaker.say("Fel vid kommando.")
        finally:
            processing.release()

    def confirm(plan) -> bool:
        return overlay.confirm(plan.thought or ", ".join(a.action for a in plan.actions))

    def notify(message: str) -> None:
        speaker.say(message)
        set_status(message[:100])

    executor = Executor(config, confirm=confirm, assert_callback=check_screen, notify_callback=notify)
    test_executor = Executor(config, confirm=None, assert_callback=check_screen, notify_callback=notify)

    def on_transcript(text: str) -> None:
        if not text:
            set_status("Hörde inget – försök igen", busy=False)
            return
        set_status(f'"{text}"', busy=True)
        handle_command(text, source="voice")

    voice = VoiceInput(config, on_transcript)
    hotkeys = HotkeyManager()
    runner = (
        ScenarioRunner(
            config,
            planner,
            test_executor,
            verifier,
            on_progress=set_status,
            bridge=bridge,
            on_failure=lambda message: speaker.say(message),
            probe=probe,
            baseline=baseline,
        )
        if planner
        else None
    )

    def active_scenario() -> Scenario:
        if config.scenario_file:
            return Scenario.load(config.scenario_file)
        return get_scenario(config.test_scenario) or BUILT_IN[0]

    def run_tests(run_all: bool = False) -> None:
        if runner is None:
            set_status("AI inte konfigurerad – kan inte köra tester", busy=True)
            return
        if not processing.acquire(blocking=False):
            set_status("Redan igång – vänta ett ögonblick", busy=True)
            return

        def worker() -> None:
            try:
                scenarios = list(BUILT_IN) if run_all else [active_scenario()]
                for scenario in scenarios:
                    report = runner.run(scenario)
                    state.last_report = report.html_path
                set_status(f"Tester klart – rapporter i {config.reports_dir}/", busy=False)
                speaker.say("Tester klara.")
            except Exception as exc:
                log.exception("Testkörning misslyckades: %s", exc)
                metrics.record_error(str(exc))
                set_status(f"Testfel: {exc}", busy=True)
            finally:
                processing.release()

        threading.Thread(target=worker, daemon=True).start()

    def toggle_dry_run() -> None:
        value = not executor.dry_run
        executor.dry_run = value
        test_executor.dry_run = value
        state.dry_run = value
        state.set(f"Dry-run {'PÅ' if value else 'AV'}")
        set_status(f"Dry-run {'PÅ' if value else 'AV'}", busy=False)
        speaker.say(f"Dry run {'på' if value else 'av'}.")

    def toggle_pause() -> None:
        value = not state.paused
        state.paused = value
        executor.paused = value
        test_executor.paused = value
        set_status(f" {'Pausad' if value else 'Kör igen'}", busy=False)
        speaker.say("Pausad." if value else "Kör igen.")

    def repeat_last() -> None:
        if state.last_command:
            handle_command(state.last_command, source="repeat")
        else:
            set_status("Inget kommando att upprepa", busy=False)

    overlay.on_submit = handle_command
    overlay.on_history = lambda commands: set_status("Historik sparad", busy=False)
    hotkeys.bind(config.text_hotkey, lambda: overlay.show())
    hotkeys.bind(config.repeat_hotkey, repeat_last)
    if config.voice_enabled:
        hotkeys.bind_hold(config.voice_hotkey, voice.start, voice.stop)
    hotkeys.bind(config.panic_hotkey, lambda: (executor.abort(), test_executor.abort(), set_status("Panik – avbröt allt", busy=False)))

    # Tk runs on its own thread; pystray owns the main thread's message loop.
    overlay_thread = threading.Thread(target=overlay.run, daemon=True)
    overlay_thread.start()
    overlay.wait_until_ready()
    hotkeys.start()

    dashboard = Dashboard(config, state, lambda text: handle_command(text, source="dashboard"), runner.reports_root if runner else Path(__file__).with_name(config.reports_dir))
    dashboard.start()

    import pystray

    def action_show(icon, item) -> None:
        overlay.show()

    def action_run_test(icon, item) -> None:
        run_tests(False)

    def action_run_all(icon, item) -> None:
        run_tests(True)

    def action_dry(icon, item) -> None:
        toggle_dry_run()

    def action_pause(icon, item) -> None:
        toggle_pause()

    def action_repeat(icon, item) -> None:
        repeat_last()

    def action_dashboard(icon, item) -> None:
        if config.dashboard_enabled:
            webbrowser.open(f"http://127.0.0.1:{config.dashboard_port}/")

    def action_reports(icon, item) -> None:
        folder = runner.reports_root if runner else Path(__file__).with_name(config.reports_dir)
        try:
            os.startfile(str(folder))  # noqa: S606
        except Exception:
            webbrowser.open(folder.as_uri())

    def action_panic(icon, item) -> None:
        executor.abort()
        test_executor.abort()
        set_status("Panik – avbröt alla åtgärder", busy=False)

    def action_quit(icon, item) -> None:
        icon.stop()

    items: list = [
        pystray.MenuItem("Skriv kommando", action_show, default=True),
        pystray.MenuItem(f"Röst (håll {config.voice_hotkey})", lambda i, m: None, enabled=config.voice_enabled),
        pystray.MenuItem("Upprepa senaste", action_repeat, enabled=lambda item: bool(state.last_command)),
        pystray.MenuItem("Dry-run", action_dry, checked=lambda item: state.dry_run),
        pystray.MenuItem("Pausa / återuppta", action_pause, checked=lambda item: state.paused),
    ]
    if config.game_mode:
        try:
            test_name = active_scenario().name
        except Exception:
            test_name = config.test_scenario
        items += [
            pystray.MenuItem(f"Kör test: {test_name}", action_run_test),
            pystray.MenuItem("Kör alla tester", action_run_all),
        ]
    items += [
        pystray.MenuItem(
            "Verktyg",
            pystray.Menu(
                pystray.MenuItem("Live-dashboard", action_dashboard, enabled=config.dashboard_enabled),
                pystray.MenuItem("Öppna rapporter", action_reports),
            ),
        ),
        pystray.MenuItem(f"Panik ({config.panic_hotkey})", action_panic),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Avsluta", action_quit),
    ]

    icon = pystray.Icon("ai-pc-control", make_icon(), "AI PC Control — QA Copilot Pro", pystray.Menu(*items))
    log.info(
        "Klart. text=%s röst=%s upprepa=%s panik=%s dashboard=%s",
        config.text_hotkey, config.voice_hotkey, config.repeat_hotkey, config.panic_hotkey,
        f"http://127.0.0.1:{config.dashboard_port}" if config.dashboard_enabled else "av",
    )
    icon.run()

    dashboard.stop()
    hotkeys.stop()
    overlay.quit()
    log.info("Avslutad.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AI PC Control - QA Copilot Pro")
    parser.add_argument("--doctor", action="store_true", help="kontrollera miljön och avsluta")
    parser.add_argument("--list-scenarios", action="store_true", help="lista inbyggda scenarier")
    parser.add_argument("--list-matrices", action="store_true", help="lista tillgängliga matriser")
    parser.add_argument("--run", metavar="SCENARIO", help="kör ett scenario huvudlöst och avsluta")
    parser.add_argument("--matrix", metavar="NAME", help="kör scenariot över en matris")
    parser.add_argument("--author", metavar="TEXT", help="skapa ett scenario med AI:n")
    parser.add_argument("--out", metavar="PATH", help="sökväg för --author")
    parser.add_argument("--repeat", type=int, default=1, help="antal körningar av scenariot")
    parser.add_argument("--fuzz", type=int, metavar="N", help="kör N seedade slumpsteg")
    parser.add_argument("--seed", type=int, help="seed för fuzz (annars FUZZ_SEED)")
    parser.add_argument("--baseline-save", action="store_true", help="spara nuvarande skärmar som baselines")
    parser.add_argument("--baseline-check", action="store_true", help="jämför med sparade baselines")
    parser.add_argument("--dry-run", action="store_true", help="logga åtgärder utan att köra dem")
    parser.add_argument("--no-dashboard", action="store_true", help="starta inte webbdashboarden")
    return parser.parse_args()


def run_headless(
    config: Config,
    scenario_name: str,
    repeat: int,
    fuzz: int,
    seed: int | None,
    matrix: str = "",
    save_baselines: bool = False,
) -> int:
    """Run tests without tray, Tk, voice or hotkeys. Returns a CI-friendly exit code."""
    setup_logging(config)
    log = logging.getLogger("ai-control.headless")
    planner = build_planner(config, game_mode=config.game_mode)
    verifier = Verifier(config)
    bridge = BrowserBridge(config)
    if bridge.enabled:
        bridge.connect()

    def check(condition: str) -> bool:
        return verifier.check(condition).passed

    executor = Executor(config, confirm=None, assert_callback=check)
    runner = ScenarioRunner(
        config,
        planner,
        executor,
        verifier,
        bridge=bridge,
        probe=GameProbe(config, bridge),
        baseline=BaselineManager(config, Path(__file__).resolve().parent),
        save_baselines=save_baselines,
    )

    scenario = get_scenario(scenario_name)
    if fuzz:
        result = Fuzzer(config, executor, verifier, bridge).run(fuzz, seed)
        print(result.summary())
        print(f"JSON: {result.json_path}")
        print(f"HTML: {result.html_path}")
        return 0 if result.passed else 1

    if matrix:
        if scenario is None:
            print(f"Okänt scenario: {scenario_name}")
            return 2
        matrix_result = MatrixRunner(runner, config.matrix_budget, runner.reports_root).run(scenario, matrix)
        print(matrix_result.summary())
        print(f"JSON: {matrix_result.summary_path}")
        print(f"HTML: {matrix_result.html_path}")
        return 0 if matrix_result.passed else 1

    if scenario is None:
        print(f"Okänt scenario: {scenario_name}")
        print("Tillgängliga:", ", ".join(s.name for s in BUILT_IN))
        return 2

    report = None
    for index in range(max(1, repeat)):
        log.info("Körning %d/%d", index + 1, repeat)
        report = runner.run(scenario)
    if report is None:
        return 2
    print(report.summary())
    print(f"JSON: {report.json_path}")
    print(f"HTML: {report.html_path}")
    return 0 if report.passed else 1


if __name__ == "__main__":
    args = parse_args()
    if args.doctor:
        from tools.doctor import main as doctor_main

        raise SystemExit(doctor_main())
    if args.list_scenarios:
        for scenario in BUILT_IN:
            print(f"{scenario.name:20} {scenario.description}")
        raise SystemExit(0)
    if args.list_matrices:
        for name, variables in MATRICES.items():
            print(f"{name:14} " + ", ".join(f"{key}={len(values)}" for key, values in variables.items()))
        raise SystemExit(0)
    if args.author:
        try:
            path = author_scenario(Config(), args.author, args.out)
        except Exception as exc:
            print(f"Kunde inte skapa scenario: {exc}")
            raise SystemExit(1)
        print(f"Scenario skapat: {path}")
        raise SystemExit(0)

    active_config = Config()
    if args.dry_run:
        active_config = replace(active_config, dry_run=True)
    if args.no_dashboard:
        active_config = replace(active_config, dashboard_enabled=False)
    if args.baseline_save:
        active_config = replace(active_config, baseline_enabled=True, baseline_check=False)
    if args.baseline_check:
        active_config = replace(active_config, baseline_enabled=True, baseline_check=True)

    if args.run or args.fuzz or args.matrix:
        raise SystemExit(
            run_headless(
                active_config,
                args.run or active_config.test_scenario,
                args.repeat,
                args.fuzz or 0,
                args.seed,
                args.matrix or "",
                args.baseline_save,
            )
        )

    main(active_config)
