' Startar appen utan konsolfönster, med projektets egna venv.
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw = folder & "\.venv\Scripts\pythonw.exe"
If Not fso.FileExists(pythonw) Then
    pythonw = "C:\Users\Genc\AppData\Local\Python\pythoncore-3.13-64\pythonw.exe"
End If
If Not fso.FileExists(pythonw) Then
    pythonw = "pythonw.exe"
End If
shell.CurrentDirectory = folder
shell.Run """" & pythonw & """ """ & folder & "\main.py""", 0, False
