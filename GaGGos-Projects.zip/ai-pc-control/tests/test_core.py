"""Enhetstester för parser, scenarier, diff och rapporter."""
from __future__ import annotations

import sys
from dataclasses import replace
from pathlib import Path

import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import Config  # noqa: E402
from core.baseline import BaselineManager  # noqa: E402
from core.browser_bridge import BrowserBridge  # noqa: E402
from core.commands import parse_plan  # noqa: E402
from core.executor import Executor  # noqa: E402
from core.game_probe import STATE_EXPRESSION  # noqa: E402
from core.llm import extract_json  # noqa: E402
from core.state import StateStore  # noqa: E402
from core.verify import diff_ratio, is_black  # noqa: E402
from core.recorder import FrameRecorder  # noqa: E402
from core.verify import Verification  # noqa: E402
from core.webhook import notify as notify_webhook  # noqa: E402
from core.window import focus_game_window  # noqa: E402
from game.author import author_scenario  # noqa: E402
from game.fuzzer import Fuzzer  # noqa: E402
from game.invariants import check_invariants  # noqa: E402
from game.matrix import MatrixRunner, materialize  # noqa: E402
from game.scenarios import BUILT_IN, Scenario, TestStep as _TestStep, get_scenario  # noqa: E402
from game.tft_tester import (  # noqa: E402
    ScenarioRunner,
    StepResult as _StepResult,
    TestReport as _TestReport,
)
from ui.report import build_html, build_index  # noqa: E402


def test_parse_plan_valid_and_invalid():
    plan = parse_plan(
        {
            "thought": "test",
            "observation": "ser arenan",
            "risk": "low",
            "actions": [
                {"action": "hotkey", "keys": ["ctrl", "a"]},
                {"action": "click", "x": 100.4, "y": 200.6},
                {"action": "paste", "text": "åäö"},
                {"action": "nonsense"},
            ],
        }
    )
    assert [a.action for a in plan.actions] == ["hotkey", "click", "paste"]
    assert plan.actions[1].x == 100 and plan.actions[1].y == 201
    assert plan.observation == "ser arenan"
    assert any("nonsense" in error for error in plan.errors)


def test_parse_plan_repeat_clamped():
    plan = parse_plan({"actions": [{"action": "repeat", "times": 999, "actions": []}]})
    assert plan.actions[0].times == 100


def test_extract_json_from_fence():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('här: {"b": 2} klart') == {"b": 2}


def test_builtin_scenarios_exist():
    names = {s.name for s in BUILT_IN}
    assert {"squadron-smoke", "squadron-build", "squadron-economy", "squadron-combat", "squadron-soak"} <= names
    assert get_scenario("SQUADRON-SMOKE") is not None
    assert get_scenario("finns-inte") is None


def test_test_step_repeat_clamp():
    assert _TestStep(name="x", repeat=999).repeat == 50
    assert _TestStep(name="x", repeat=0).repeat == 1


def test_diff_ratio_and_black():
    a = Image.new("RGB", (40, 40), (10, 10, 10))
    b = Image.new("RGB", (40, 40), (10, 10, 10))
    assert diff_ratio(a, b) == 0.0
    assert is_black(a) is True
    b.putpixel((0, 0), (255, 255, 255))
    assert diff_ratio(a, b) > 0


def test_state_history(tmp_path):
    config = replace(Config(), history_file=str(tmp_path / "history.jsonl"))
    state = StateStore(config)
    state.add_command("bygg torn", "text")
    state.add_command("starta vågen", "voice")
    assert state.last_command == "starta vågen"
    assert [e["command"] for e in state.recent_history()] == ["starta vågen", "bygg torn"]
    assert (tmp_path / "history.jsonl").exists()


def test_dry_run_does_not_execute():
    config = replace(Config(), dry_run=True, action_delay=0)
    executor = Executor(config)
    plan = parse_plan({"actions": [{"action": "click", "x": 10, "y": 10}, {"action": "press", "key": "f5"}]})
    assert executor.run(plan) == 2


def test_html_report_contains_badges():
    data = {
        "scenario": "demo",
        "description": "test",
        "started_at": "now",
        "finished_at": "later",
        "passed": True,
        "duration_s": 1.5,
        "results": [
            {
                "name": "steg 1",
                "command": "tryck enter",
                "thought": "t",
                "observation": "o",
                "actions_run": 1,
                "duration_s": 0.2,
                "verification": {"passed": True, "detail": "ok", "evidence": "ser HUD"},
                "passed": True,
            }
        ],
    }
    html = build_html(data, [None], [False])
    assert "PASS" in html and "demo" in html and "ser HUD" in html


def test_scenario_runner_produces_reports(tmp_path):
    config = replace(
        Config(),
        reports_dir=str(tmp_path),
        test_delay=0,
        capture_screenshots=False,
        frozen_detection=False,
    )
    planner = type("P", (), {"plan": lambda s, t, c, hint="": parse_plan({"actions": [{"action": "wait", "seconds": 0}]})})
    executor = type("E", (), {"run": lambda s, p: len(p.actions)})()
    verifier = type(
        "V",
        (),
        {
            "check": lambda s, c, x=None: Verification(c, True, "ok", "ser arenan"),
            "is_frozen": lambda s: (False, 0.1),
        },
    )()
    runner = ScenarioRunner(config, planner(), executor, verifier)
    report = runner.run(get_scenario("smoke"))
    assert report.passed
    assert Path(report.html_path).exists()
    assert Path(report.json_path).exists()


def test_cdp_event_recording():
    bridge = BrowserBridge(replace(Config(), browser_cdp_enabled=False))
    bridge._record_event(
        {"method": "Runtime.consoleAPICalled", "params": {"type": "error", "args": [{"value": "boom"}]}}
    )
    bridge._record_event({"method": "Runtime.exceptionThrown", "params": {"exceptionDetails": {"text": "oops"}}})
    bridge._record_event({"method": "Runtime.consoleAPICalled", "params": {"type": "log", "args": []}})
    assert len(bridge.errors()) == 2
    bridge.clear()
    assert bridge.errors() == []


def test_frame_recorder_disabled(tmp_path):
    recorder = FrameRecorder(False)
    recorder.add()
    assert recorder.save(tmp_path / "run.gif") == ""


def test_report_fails_on_console_error():
    report = _TestReport(scenario="x", results=[_StepResult(name="s", command="c")])
    assert report.passed
    report.console_errors = [{"level": "error", "text": "boom"}]
    assert not report.passed
    report.fail_on_console_error = False
    assert report.passed


def test_build_index_contains_pass_rate():
    html = build_index(
        [
            {"scenario": "a", "at": "now", "passed": True, "steps": 2, "passed_steps": 2, "duration_s": 1, "html": "a/report.html"},
            {"scenario": "b", "at": "now", "passed": False, "steps": 2, "passed_steps": 1, "duration_s": 2, "html": "b/report.html"},
        ]
    )
    assert "50%" in html and "PASS" in html and "FAIL" in html


def test_scenario_expect_state_roundtrip(tmp_path):
    scenario = Scenario(
        name="t",
        description="",
        steps=[_TestStep(name="s", expect_state="document.body.innerText.length > 0")],
    )
    path = tmp_path / "scenario.json"
    scenario.save(path)
    loaded = Scenario.load(path)
    assert loaded.steps[0].expect_state == "document.body.innerText.length > 0"


def test_fuzzer_is_deterministic(tmp_path):
    config = replace(
        Config(),
        reports_dir=str(tmp_path),
        frozen_detection=False,
        gif_recording=False,
    )
    executor = type("E", (), {"run": lambda s, p: len(p.actions)})()
    verifier = type("V", (), {"is_frozen": lambda s, w=0.6: (False, 0.1)})()
    fuzzer = Fuzzer(config, executor, verifier)
    first = fuzzer.run(6, seed=42)
    second = fuzzer.run(6, seed=42)
    assert [step.command for step in first.results] == [step.command for step in second.results]
    assert Path(first.json_path).exists()


def test_probe_expression_targets_real_game():
    assert "window.Squadron" in STATE_EXPRESSION
    assert "UI.game" in STATE_EXPRESSION
    assert "minerals" in STATE_EXPRESSION


def test_invariants_detect_common_bugs():
    assert check_invariants(None) == []
    healthy = {
        "minerals": 500, "gas": 40, "supplyUsed": 4, "supplyMax": 10,
        "ssHp": 100, "ssMaxHp": 100, "wave": 3, "phase": "BuildPhase",
        "speed": 1, "gasTickAcc": 0.4, "towers": 2,
    }
    assert check_invariants(healthy) == []
    broken = {**healthy, "minerals": -5, "supplyUsed": 12, "wave": 99, "phase": "Bogus", "speed": 7}
    violations = check_invariants(broken)
    assert len(violations) == 5
    assert any("Mineraler" in v for v in violations)


def test_baseline_save_and_check(tmp_path):
    config = replace(Config(), baseline_enabled=True, baseline_check=True, baseline_dir="baselines")
    manager = BaselineManager(config, tmp_path)
    image = Image.new("RGB", (640, 360), (30, 30, 30))
    manager.save("demo", "steg 1", image)
    result = manager.check("demo", "steg 1", image)
    assert result["passed"] is True and result["diff"] == 0.0
    changed = Image.new("RGB", (640, 360), (220, 30, 30))
    assert manager.check("demo", "steg 1", changed)["passed"] is False
    assert manager.check("annat", "steg 1", image).get("skipped") is True


def test_matrix_materialize_and_budget():
    scenario = get_scenario("smoke")
    copy = materialize(scenario, {"builder": "ghost"})
    assert "{builder}" not in copy.name
    runner = type("R", (), {"reports_root": Path("x")})()
    matrix = MatrixRunner(runner, budget=3)  # type: ignore[arg-type]
    assert len(matrix.combinations("builders")) == 3
    assert len(matrix.combinations("difficulty")) == 3


def test_focus_disabled_returns_empty():
    config = replace(Config(), auto_focus_window=False)
    assert focus_game_window(config) == ""


def test_webhook_skipped_without_url():
    payload = {"scenario": "x", "passed": True}
    assert notify_webhook(replace(Config(), webhook_url=""), payload) is False


def test_webhook_posts_on_fail(monkeypatch):
    calls = []

    class Response:
        status_code = 200

    monkeypatch.setattr("core.webhook.requests.post", lambda url, json=None, timeout=None: calls.append((url, json)) or Response())
    config = replace(Config(), webhook_url="http://example.test/hook", webhook_on="fail")
    assert notify_webhook(config, {"scenario": "x", "passed": False}) is True
    assert calls and calls[0][1]["scenario"] == "x"


def test_author_scenario_validates_ai_output(tmp_path, monkeypatch):
    payload = (
        '{"name":"ai-test","description":"test","steps":['
        '{"name":"Steg","command":"tryck enter","expect":"Vågen startar."}]}'
    )
    monkeypatch.setattr("game.author.generate", lambda *a, **k: payload)
    path = author_scenario(replace(Config()), "testa att starta en våg", tmp_path / "generated.json")
    loaded = Scenario.load(path)
    assert loaded.name == "ai-test"
    assert loaded.steps[0].command == "tryck enter"



