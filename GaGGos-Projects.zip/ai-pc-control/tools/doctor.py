"""Diagnostics for AI PC Control — run with: py -3.13 tools/doctor.py"""
from __future__ import annotations

import importlib
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config  # noqa: E402

OK, WARN, FAIL = "OK", "VARNING", "FEL"


def check(name: str, func) -> tuple[str, str]:
    try:
        result = func()
        if isinstance(result, tuple):
            return result
        return OK, str(result)
    except Exception as exc:
        return FAIL, str(exc)


def main() -> int:
    config = Config()
    results: list[tuple[str, str, str]] = []

    def add(name: str, status: str, detail: str) -> None:
        results.append((name, status, detail))

    status, detail = check("Python", lambda: (OK, f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"))
    add("Python", status, detail)
    status, detail = check(
        "Python-version",
        lambda: (OK, "stöds") if sys.version_info >= (3, 10) else (FAIL, "kräver 3.10+ (3.13 rekommenderas för Whisper)"),
    )
    add("Python-version", status, detail)

    for module in ["pyautogui", "pynput", "pystray", "PIL", "pydantic", "requests", "anthropic", "sounddevice", "websocket", "faster_whisper"]:
        status, detail = check(f"import {module}", lambda m=module: (OK, importlib.import_module(m).__name__))
        add(f"modul {module}", status, detail)

    import requests

    def ollama() -> tuple[str, str]:
        response = requests.get(f"{config.ollama_base_url.rstrip('/')}/api/tags", timeout=4)
        response.raise_for_status()
        models = [m.get("name", "") for m in response.json().get("models", [])]
        if any(config.ollama_model.split(":")[0] in name for name in models):
            return OK, f"Ollama svarar, modell {config.ollama_model} finns"
        return WARN, f"Ollama svarar men modellen {config.ollama_model} saknas (kör: ollama pull {config.ollama_model})"

    status, detail = check("Ollama", ollama)
    add("Ollama", status, detail)

    status, detail = check(
        "Anthropic-nyckel",
        lambda: (OK, "satt") if config.anthropic_api_key and not config.anthropic_api_key.startswith("sk-ant-...") else (WARN, "inte satt (behövs bara om AI_PROVIDER=anthropic)"),
    )
    add("Anthropic-nyckel", status, detail)

    def microphone() -> tuple[str, str]:
        import sounddevice as sd

        devices = sd.query_devices()
        inputs = [d for d in devices if d.get("max_input_channels", 0) > 0]
        return (OK, f"{len(inputs)} mikrofon(er)") if inputs else (WARN, "ingen mikrofon hittades")

    status, detail = check("Mikrofon", microphone)
    add("Mikrofon", status, detail)

    def tts() -> tuple[str, str]:
        import subprocess

        script = "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices().Count"
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
        count = result.stdout.strip()
        return (OK, f"{count} röster") if result.returncode == 0 else (WARN, "System.Speech ej tillgängligt")

    status, detail = check("TTS", tts)
    add("TTS", status, detail)

    def port() -> tuple[str, str]:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", config.dashboard_port))
        return OK, f"port {config.dashboard_port} ledig"

    status, detail = check("Dashboard-port", port)
    add("Dashboard-port", status, detail)

    if config.browser_cdp_enabled:
        def cdp() -> tuple[str, str]:
            response = requests.get(f"{config.cdp_url.rstrip('/')}/json", timeout=4)
            pages = [t for t in response.json() if t.get("type") == "page"]
            return (OK, f"{len(pages)} sidor") if pages else (WARN, "inga sidor i CDP")

        status, detail = check("CDP", cdp)
        add("CDP", status, detail)
    else:
        add("CDP", WARN, "avstängt (BROWSER_CDP_ENABLED=false)")

    reports = Path(__file__).resolve().parent.parent / config.reports_dir
    status, detail = check("Rapportmapp", lambda: (OK, str(reports)) if reports.parent.exists() else (FAIL, "fel sökväg"))
    add("Rapportmapp", status, detail)

    width = max(len(name) for name, _, _ in results)
    for name, status, detail in results:
        print(f"{status:8} {name:<{width}}  {detail}")
    failures = sum(1 for _, status, _ in results if status == FAIL)
    print(f"\n{len(results) - failures}/{len(results)} kontroller utan fel.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
