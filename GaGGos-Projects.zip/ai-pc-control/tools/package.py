"""Package the QA tool into the Desktop zips and a standalone release zip.

Usage:  py -3.13 tools/package.py
"""
from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DESKTOP = Path(os.environ.get("USERPROFILE", "")) / "Desktop"
SOURCE = ROOT

EXCLUDE_DIRS = {".venv", "__pycache__", ".pytest_cache", "reports", "baselines", "scenarios", ".git"}
EXCLUDE_FILES = {".env", "ai-control.log", "command-history.jsonl"}


def copy_source(destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in SOURCE.rglob("*"):
        relative = item.relative_to(SOURCE)
        if any(part in EXCLUDE_DIRS for part in relative.parts[:-1]):
            continue
        if item.is_dir():
            if item.name not in EXCLUDE_DIRS:
                (destination / relative).mkdir(parents=True, exist_ok=True)
            continue
        if item.name in EXCLUDE_FILES:
            continue
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)


def zip_directory(folder: Path, zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for item in sorted(folder.rglob("*")):
            if item.is_file():
                archive.write(item, item.relative_to(folder).as_posix())


def update_existing(zip_path: Path, folder_name: str) -> bool:
    if not zip_path.exists():
        return False
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        extracted = work / "existing"
        extracted.mkdir()
        with zipfile.ZipFile(zip_path, "r") as archive:
            archive.extractall(extracted)
        # Remove a previously packaged copy so the zip never accumulates stale files.
        old = extracted / folder_name
        if old.exists():
            shutil.rmtree(old)
        copy_source(old)

        new_zip = work / "new.zip"
        zip_directory(extracted, new_zip)
        shutil.move(str(new_zip), str(zip_path))
    return True


def main() -> None:
    if not DESKTOP.exists():
        raise SystemExit(f"Skrivbordet hittades inte: {DESKTOP}")

    updated: list[str] = []
    for name, folder in [
        ("SquadronTD_Pro_Edition.zip", "qa/ai-pc-control"),
        ("GaGGos-Projects.zip", "ai-pc-control"),
    ]:
        if update_existing(DESKTOP / name, folder):
            updated.append(f"{name}  (+ {folder}/)")

    with tempfile.TemporaryDirectory() as tmp:
        staging = Path(tmp) / "ai-pc-control"
        copy_source(staging)
        release = DESKTOP / "AI-PC-Control-Pro.zip"
        zip_directory(staging, release)
        updated.append(f"{release.name}  ({sum(1 for p in staging.rglob('*') if p.is_file())} filer)")

    print("Paketerat:")
    for line in updated:
        print(" -", line)


if __name__ == "__main__":
    main()
