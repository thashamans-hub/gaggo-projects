"""Local live dashboard: status, metrics, history and a command form."""
from __future__ import annotations

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from core.state import StateStore

log = logging.getLogger("ai-control.dashboard")

PAGE = """<!doctype html><html lang="sv"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>AI PC Control — Live</title>
<style>
:root{color-scheme:dark;--bg:#0d1117;--panel:#161b22;--line:#30363d;--txt:#e6edf3;--mut:#8b949e;
--green:#3fb950;--red:#f85149;--blue:#58a6ff;--amber:#d29922}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);font:14px/1.5 "Segoe UI",system-ui,sans-serif}
.wrap{max-width:1100px;margin:0 auto;padding:26px 20px 60px}h1{font-size:22px;margin:0}
.sub{color:var(--mut);margin-bottom:18px}.dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--green);margin-right:7px}
.dot.busy{background:var(--amber)}.dot.pause{background:var(--red)}
.grid{display:grid;grid-template-columns:2fr 1fr;gap:16px;flex-wrap:wrap}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:16px;min-width:300px;flex:1}
.panel h2{font-size:13px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut);margin:0 0 12px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(105px,1fr));gap:10px}
.stat{background:#1c2128;border:1px solid var(--line);border-radius:8px;padding:10px}
.stat b{display:block;font-size:20px}.stat span{color:var(--mut);font-size:11px;text-transform:uppercase}
input,button{font:inherit;background:#21262d;color:var(--txt);border:1px solid var(--line);border-radius:7px;padding:9px 11px}
input{flex:1}button{background:var(--blue);color:#06121f;border-color:var(--blue);font-weight:700;cursor:pointer}
form{display:flex;gap:8px}ul{list-style:none;margin:0;padding:0}li{padding:7px 0;border-bottom:1px solid var(--line);font-size:13px}
li:last-child{border:0}.mut{color:var(--mut)}.tag{font-size:11px;color:var(--mut);border:1px solid var(--line);border-radius:999px;padding:2px 8px;margin-left:6px}
a{color:var(--blue);text-decoration:none}a:hover{text-decoration:underline}
</style></head><body><div class="wrap">
<h1>AI PC Control <span class="tag">live</span></h1>
<div class="sub"><span id="dot" class="dot"></span><span id="status">Ansluter…</span></div>
<div class="grid">
<div class="panel"><h2>Skicka kommando</h2><form id="f"><input id="cmd" placeholder="t.ex. bygg tre torn och starta vågen" autocomplete="off"><button>Skicka</button></form>
<p class="mut" id="msg"></p></div>
<div class="panel"><h2>Metriker</h2><div class="stats" id="stats"></div></div>
<div class="panel"><h2>Kommandohistorik</h2><ul id="history"></ul></div>
<div class="panel"><h2>Senaste rapporter</h2><ul id="reports"></ul></div>
</div></div><script>
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function refresh(){try{const r=await fetch('/api/state');const d=await r.json();
const dot=document.getElementById('dot');dot.className='dot'+(d.paused?' pause':d.busy?' busy':'');
document.getElementById('status').textContent=d.status+(d.dry_run?'  [DRY-RUN]':'')+(d.paused?'  [PAUSAD]':'');
const m=d.metrics||{};document.getElementById('stats').innerHTML=[
['Kommandon',m.commands],['Åtgärder',m.actions],['LLM-anrop',m.llm_calls],['Snitt LLM',m.avg_llm_latency_ms+' ms'],
['Fel',m.llm_failures],['Tester',m.tests_run],['Steg pass',m.steps_passed],['Steg fail',m.steps_failed]]
.map(([k,v])=>`<div class="stat"><b>${esc(v)}</b><span>${esc(k)}</span></div>`).join('');
document.getElementById('history').innerHTML=(d.history||[]).map(h=>
`<li><span class="mut">${esc(h.at)}</span> <span class="tag">${esc(h.source)}</span><br>${esc(h.command)}</li>`).join('')||'<li class="mut">Inga kommandon ännu</li>';
document.getElementById('reports').innerHTML=(d.reports||[]).map(p=>
`<li><a href="/report/${encodeURIComponent(p.name)}" target="_blank">${esc(p.name)}</a></li>`).join('')||'<li class="mut">Inga rapporter ännu</li>';
}catch(e){document.getElementById('status').textContent='Dashboard offline'} }
setInterval(refresh,2000);refresh();
document.getElementById('f').addEventListener('submit',async e=>{e.preventDefault();
const cmd=document.getElementById('cmd');if(!cmd.value.trim())return;
const msg=document.getElementById('msg');msg.textContent='Skickar…';
try{const r=await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:cmd.value})});
const d=await r.json();msg.textContent=d.ok?'Skickat':'Fel: '+(d.error||'okänt');if(d.ok)cmd.value='';}
catch(err){msg.textContent='Fel: '+err}refresh();});
</script></body></html>"""


class Dashboard:
    def __init__(
        self,
        config,
        state: StateStore,
        command_callback: Callable[[str], None],
        reports_root: Path,
    ) -> None:
        self.config = config
        self.state = state
        self.command_callback = command_callback
        self.reports_root = reports_root
        self.server: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None

    def _reports(self) -> list[dict]:
        items: list[dict] = []
        try:
            for path in sorted(self.reports_root.rglob("report.html"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
                items.append({"name": path.parent.name, "path": str(path)})
        except Exception:
            pass
        return items

    def _make_handler(self):
        dashboard = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args) -> None:
                log.debug("dashboard: " + fmt, *args)

            def _send(self, code: int, body: bytes, content_type: str) -> None:
                self.send_response(code)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:  # noqa: N802
                if self.path.startswith("/api/state"):
                    data = dashboard.state.snapshot()
                    data["reports"] = dashboard._reports()
                    self._send(200, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
                elif self.path.startswith("/report/"):
                    from urllib.parse import unquote

                    name = unquote(self.path[len("/report/") :]).replace("\\", "/").replace("..", "")
                    path = dashboard.reports_root / name / "report.html"
                    if path.exists():
                        self._send(200, path.read_bytes(), "text/html; charset=utf-8")
                    else:
                        self._send(404, b"Not found", "text/plain")
                elif self.path in {"/", "/index.html"}:
                    self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
                else:
                    self._send(204, b"", "text/plain")

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/api/command":
                    self._send(404, b"Not found", "text/plain")
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    payload = json.loads(self.rfile.read(length) or b"{}")
                    command = str(payload.get("command", "")).strip()
                    if not command:
                        raise ValueError("Tomt kommando")
                    dashboard.command_callback(command)
                    body = json.dumps({"ok": True}, ensure_ascii=False).encode("utf-8")
                except Exception as exc:
                    body = json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False).encode("utf-8")
                self._send(200, body, "application/json; charset=utf-8")

        return Handler

    def start(self) -> None:
        if not self.config.dashboard_enabled:
            return
        try:
            self.server = ThreadingHTTPServer(("127.0.0.1", self.config.dashboard_port), self._make_handler())
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
            log.info("Dashboard: http://127.0.0.1:%s", self.config.dashboard_port)
        except Exception as exc:
            log.warning("Kunde inte starta dashboard: %s", exc)

    def stop(self) -> None:
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
