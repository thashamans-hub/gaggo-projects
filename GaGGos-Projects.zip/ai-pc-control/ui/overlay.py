"""Small always-on-top input overlay. No window stealing focus until invoked."""
from __future__ import annotations

import logging
import threading
import tkinter as tk

log = logging.getLogger("ai-control.overlay")


class Overlay:
    def __init__(self) -> None:
        self.on_submit = None  # type: ignore[assignment]
        self.on_history = None  # type: ignore[assignment]
        self._history: list[str] = []
        self._history_index = -1
        self._root: tk.Tk | None = None
        self._entry: tk.Entry | None = None
        self._status: tk.Label | None = None
        self._var: tk.StringVar | None = None
        self._ready = threading.Event()
        self._confirm_event: threading.Event | None = None
        self._confirm_result = False

    # ── lifecycle ──────────────────────────────────────────────
    def run(self) -> None:
        """Build the UI and block in Tk's mainloop. Call from the main thread."""
        root = tk.Tk()
        self._root = root
        root.withdraw()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        root.attributes("-alpha", 0.95)
        root.configure(bg="#1b1b1f")

        frame = tk.Frame(root, bg="#1b1b1f", padx=14, pady=10)
        frame.pack(fill="both", expand=True)

        self._var = tk.StringVar()
        self._status = tk.Label(
            frame,
            text="Skriv ett kommando  ·  Enter = kör  ·  Esc = stäng",
            fg="#9aa0a6",
            bg="#1b1b1f",
            anchor="w",
            font=("Segoe UI", 9),
        )
        self._status.pack(fill="x")

        self._entry = tk.Entry(
            frame,
            textvariable=self._var,
            bg="#2b2b31",
            fg="#f2f2f2",
            insertbackground="#f2f2f2",
            relief="flat",
            font=("Segoe UI", 13),
        )
        self._entry.pack(fill="x", pady=(8, 0), ipady=6)
        self._entry.bind("<Return>", lambda _: self._submit())
        self._entry.bind("<Escape>", lambda _: self.hide())
        self._entry.bind("<Up>", lambda _: self._history_step(-1))
        self._entry.bind("<Down>", lambda _: self._history_step(1))

        self._ready.set()
        root.mainloop()

    def quit(self) -> None:
        if self._root is not None:
            self._root.after(0, self._root.destroy)

    def wait_until_ready(self, timeout: float = 10.0) -> bool:
        return self._ready.wait(timeout)

    # ── thread-safe helpers ────────────────────────────────────
    def _after(self, function, *args) -> None:
        if self._root is not None:
            self._root.after(0, lambda: function(*args))

    def show(self, prefill: str = "") -> None:
        self.wait_until_ready()
        self._after(self._show_now, prefill)

    def _show_now(self, prefill: str) -> None:
        root = self._root
        if root is None:
            return
        width, height = 560, 96
        x = max(0, (root.winfo_screenwidth() - width) // 2)
        y = max(0, root.winfo_screenheight() - height - 120)
        root.geometry(f"{width}x{height}+{x}+{y}")
        root.deiconify()
        root.lift()
        root.attributes("-topmost", True)
        if self._var is not None:
            self._var.set(prefill)
        if self._entry is not None:
            self._entry.focus_force()
            self._entry.select_range(0, "end")

    def hide(self) -> None:
        self._after(self._hide_now)

    def _hide_now(self) -> None:
        if self._root is not None:
            self._root.withdraw()

    def set_status(self, text: str, busy: bool = False) -> None:
        self._after(self._set_status_now, text, busy)

    def _set_status_now(self, text: str, busy: bool) -> None:
        if self._status is None or self._root is None:
            return
        color = "#f2c14e" if busy else "#9aa0a6"
        self._status.configure(text=text, fg=color)
        self._root.update_idletasks()

    def set_history(self, commands: list[str]) -> None:
        self._history = list(commands)
        self._history_index = -1

    def _history_step(self, direction: int) -> None:
        if not self._history or self._var is None:
            return
        self._history_index = max(-1, min(len(self._history) - 1, self._history_index + direction))
        value = self._history[self._history_index] if self._history_index >= 0 else ""
        self._var.set(value)
        if self._entry is not None:
            self._entry.icursor("end")

    def _submit(self) -> None:
        text = (self._var.get() if self._var else "").strip()
        self.hide()
        if text:
            if text not in self._history[:1]:
                self._history.insert(0, text)
                self._history = self._history[:100]
                if self.on_history:
                    self.on_history(list(self._history))
            if self.on_submit:
                callback = self.on_submit
                threading.Thread(target=callback, args=(text,), daemon=True).start()

    # ── confirmation ───────────────────────────────────────────
    def confirm(self, description: str, timeout: float = 30.0) -> bool:
        """Show a Yes/No prompt on the Tk thread and wait for the answer."""
        self.wait_until_ready()
        event = threading.Event()
        self._confirm_event = event
        self._confirm_result = False
        self._after(self._show_confirm, description)
        event.wait(timeout)
        self._confirm_event = None
        return self._confirm_result

    def _show_confirm(self, description: str) -> None:
        root = self._root
        if root is None:
            self._finish_confirm(False)
            return
        dialog = tk.Toplevel(root)
        dialog.overrideredirect(True)
        dialog.attributes("-topmost", True)
        dialog.configure(bg="#1b1b1f", padx=16, pady=12)
        dialog.geometry("+400+300")

        label = tk.Label(
            dialog,
            text=f"Riskabel åtgärd:\n\n{description[:400]}\n\nKör ändå?",
            fg="#f2f2f2",
            bg="#1b1b1f",
            justify="left",
            wraplength=440,
            font=("Segoe UI", 10),
        )
        label.pack()

        buttons = tk.Frame(dialog, bg="#1b1b1f")
        buttons.pack(pady=(12, 0))

        def answer(value: bool) -> None:
            dialog.destroy()
            self._finish_confirm(value)

        tk.Button(buttons, text="Nej", width=10, command=lambda: answer(False)).pack(side="left", padx=(0, 8))
        tk.Button(buttons, text="Ja, kör", width=10, command=lambda: answer(True)).pack(side="left")
        dialog.protocol("WM_DELETE_WINDOW", lambda: answer(False))

    def _finish_confirm(self, value: bool) -> None:
        self._confirm_result = value
        if self._confirm_event is not None:
            self._confirm_event.set()
