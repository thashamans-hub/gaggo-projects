"""Self-contained dark-theme HTML reports with embedded screenshots."""
from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from typing import Any

CSS = """
:root{color-scheme:dark;--bg:#0d1117;--panel:#161b22;--line:#30363d;--txt:#e6edf3;--mut:#8b949e;
--green:#3fb950;--red:#f85149;--amber:#d29922;--blue:#58a6ff;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font:14px/1.55 "Segoe UI",system-ui,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:32px 20px 64px}
h1{font-size:26px;margin:0 0 4px}
.sub{color:var(--mut);margin-bottom:22px}
.badge{display:inline-block;padding:4px 12px;border-radius:999px;font-weight:700;font-size:12px}
.pass{background:rgba(63,185,80,.15);color:var(--green);border:1px solid var(--green)}
.fail{background:rgba(248,81,73,.15);color:var(--red);border:1px solid var(--red)}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:20px 0 26px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.card b{display:block;font-size:22px;margin-top:4px}.card span{color:var(--mut);font-size:12px;text-transform:uppercase;letter-spacing:.06em}
table{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:12px 14px;border-bottom:1px solid var(--line);vertical-align:top}
th{background:#1c2128;color:var(--mut);font-size:12px;text-transform:uppercase;letter-spacing:.05em}
tr:last-child td{border-bottom:0}
code{background:#21262d;padding:2px 5px;border-radius:4px;font-size:12px}
.ok{color:var(--green);font-weight:700}.no{color:var(--red);font-weight:700}.warn{color:var(--amber)}
.thumb{width:200px;border:1px solid var(--line);border-radius:6px;display:block}
.wide{max-width:100%;border:1px solid var(--line);border-radius:8px;margin-top:10px}
.det{color:var(--mut);font-size:12px;max-width:320px}
.foot{color:var(--mut);font-size:12px;margin-top:18px}
"""


def _embed(path: str | None, mime: str = "image/jpeg", css: str = "thumb") -> str:
    if not path or not Path(path).exists():
        return '<span class="det"> ingen bild </span>'
    try:
        data = base64.b64encode(Path(path).read_bytes()).decode("ascii")
        return f'<img class="{css}" src="data:{mime};base64,{data}" alt="bevis">'
    except Exception:
        return '<span class="det"> bilden kunde inte läsas </span>'


def _img(path: str | None) -> str:
    return _embed(path)


def build_html(report: dict, screenshots: list[str | None], frozen: list[bool], gif: str = "") -> str:
    passed = bool(report.get("passed"))
    rows: list[str] = []
    for index, step in enumerate(report.get("results", [])):
        verification = step.get("verification") or {}
        ok = step.get("passed", False)
        shot = screenshots[index] if index < len(screenshots) else None
        was_frozen = frozen[index] if index < len(frozen) else False
        rows.append(
            "<tr>"
            f'<td><b>{html.escape(str(step.get("name", "")))}</b><br><span class="det">'
            f'{html.escape(str(step.get("thought", ""))[:160])}</span></td>'
            f'<td><code>{html.escape(str(step.get("command", ""))[:180])}</code>'
            f'<div class="det">{html.escape(str(step.get("observation", ""))[:220])}</div></td>'
            f'<td><span class="{"ok" if ok else "no"}">{"PASS" if ok else "FAIL"}</span>'
            f'<div class="det">{html.escape(str(verification.get("detail", step.get("error", ""))))}</div>'
            f'<div class="det">{html.escape(str(verification.get("evidence", ""))[:180])}</div>'
            f'{"<div class=warn>⚠ fryst skärm misstänkt</div>" if was_frozen else ""}</td>'
            f"<td>{step.get('actions_run', 0)}<div class=det>{step.get('duration_s', 0)} s</div></td>"
            f"<td>{_img(shot)}</td>"
            "</tr>"
        )

    result_count = len(report.get("results", []))
    passed_count = sum(1 for s in report.get("results", []) if s.get("passed"))
    stats = report.get("metrics", {})
    cards = [
        ("Steg", f"{passed_count}/{result_count}"),
        ("Åtgärder", str(stats.get("actions", 0))),
        ("LLM-anrop", str(stats.get("llm_calls", 0))),
        ("Snitt LLM", f"{stats.get('avg_llm_latency_ms', 0)} ms"),
        ("Fel", str(stats.get("llm_failures", 0))),
        ("Tid", f"{report.get('duration_s', 0)} s"),
    ]
    card_html = "".join(f'<div class="card"><span>{label}</span><b>{value}</b></div>' for label, value in cards)

    return f"""<!doctype html><html lang="sv"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QA-rapport — {html.escape(str(report.get('scenario', '')))}</title><style>{CSS}</style></head>
<body><div class="wrap">
<h1>QA-rapport: {html.escape(str(report.get('scenario', '')))}</h1>
<div class="sub">{html.escape(str(report.get('description', '')))}<br>
Körd {html.escape(str(report.get('started_at', '')))} → {html.escape(str(report.get('finished_at', '')))}</div>
<span class="badge {"pass" if passed else "fail"}">{"PASS" if passed else "FAIL"}</span>
<div class="cards">{card_html}</div>
{("<h2>Inspelning</h2>" + _embed(gif, "image/gif", "wide")) if gif else ""}
{("<p class='warn'>Console-fel: " + str(len(report.get("console_errors", []))) + "</p>") if report.get("console_errors") else ""}
<table><thead><tr><th>Steg</th><th>Kommando / observation</th><th>Resultat</th><th>Åtgärder</th><th>Skärmbild</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table>
<div class="foot">Genererad av AI PC Control · QA Copilot Pro · {html.escape(str(report.get('finished_at', '')))}</div>
</div></body></html>"""


def save_html(
    report: Any,
    path: Path,
    screenshots: list[str | None],
    frozen: list[bool],
    metrics: dict | None = None,
    gif: str = "",
) -> Path:
    data = report.to_dict()
    data["duration_s"] = report.duration_s
    data["metrics"] = metrics or {}
    path.write_text(build_html(data, screenshots, frozen, gif), encoding="utf-8")
    return path


def build_index(entries: list[dict]) -> str:
    rows = []
    for entry in entries:
        ok = bool(entry.get("passed"))
        rows.append(
            "<tr>"
            f'<td><a href="{html.escape(str(entry.get("html", "")))}" target="_blank">'
            f'{html.escape(str(entry.get("scenario", "")))}</a></td>'
            f'<td class="mut">{html.escape(str(entry.get("at", "")))}</td>'
            f'<td><span class="{"ok" if ok else "no"}">{"PASS" if ok else "FAIL"}</span>'
            f'{("<span class=tag>FLAKY</span>" if entry.get("flaky") else "")}</td>'
            f'<td>{entry.get("passed_steps", 0)}/{entry.get("steps", 0)}</td>'
            f'<td>{entry.get("duration_s", 0)} s</td>'
            "</tr>"
        )
    total = len(entries)
    passed = sum(1 for e in entries if e.get("passed"))
    rate = round(100 * passed / total) if total else 0
    bars = "".join(
        f'<span style="display:inline-block;width:14px;height:{"18" if e.get("passed") else "10"}px;'
        f'background:{"var(--green)" if e.get("passed") else "var(--red)"};margin-right:2px"></span>'
        for e in reversed(entries[-40:])
    )
    return f"""<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>QA-rapportindex</title>
<style>{CSS}</style></head><body><div class="wrap"><h1>QA-rapportindex</h1>
<div class="sub">{total} körningar · {rate}% pass-rate</div><div>{bars}</div>
<table><thead><tr><th>Scenario</th><th>Tid</th><th>Resultat</th><th>Steg</th><th>Duration</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table></div></body></html>"""


def save_index(reports_root: Path) -> Path:
    entries: list[dict] = []
    for path in sorted(reports_root.rglob("report.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:100]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        results = data.get("results", [])
        entries.append(
            {
                "scenario": data.get("scenario", path.parent.name),
                "at": data.get("started_at", ""),
                "passed": data.get("passed", False),
                "steps": len(results),
                "passed_steps": sum(1 for r in results if r.get("passed")),
                "duration_s": data.get("duration_s", 0),
                "html": path.parent.name + "/report.html",
            }
        )
    # Mark scenarios whose last five runs are not consistently green.
    recent: dict[str, list[bool]] = {}
    for entry in reversed(entries):
        recent.setdefault(entry["scenario"], [])
        if len(recent[entry["scenario"]]) < 5:
            recent[entry["scenario"]].append(bool(entry["passed"]))
    for entry in entries:
        results = recent.get(entry["scenario"], [])
        entry["flaky"] = len(results) >= 2 and not all(results)

    path = reports_root / "index.html"
    path.write_text(build_index(entries), encoding="utf-8")
    return path
